import SwiftUI
import UIKit
import Foundation
import Security
import Darwin
import MediaPlayer

@main
struct NextAgentApp: App {
    @StateObject private var state = AppState()
    var body: some Scene {
        WindowGroup { ModernRootView().environmentObject(state) }
    }
}

// MARK: - Models

struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let role: String
    let text: String
}

struct ToolResult {
    let success: Bool
    let output: String
}

struct RequiredAction {
    let turnId: String
    let callId: String
    let name: String
    let arguments: [String: Any]
}

// MARK: - App State

@MainActor
final class AppState: ObservableObject {
    @Published var messages: [ChatMessage] = [
        ChatMessage(role: "assistant", text: "Next Agent 0.7.14 is ready with dual-layer task status and deeper HUD/background diagnostics.")
    ]
    @Published var input = ""
    @Published var busy = false
    @Published var status = "Not configured"
    @Published var agentId = "agent_a8bca3810e67406a8076559d2ba2e10f1379810a596e4d3082"
    @Published var sessionId = UserDefaults.standard.string(forKey: "nextagent.managedSessionId") ?? ""
    @Published var model = "gpt-6-astra"
    @Published var sensitiveActions = UserDefaults.standard.bool(forKey: "nextagent.sensitiveActions")
    @Published var apiKeyDraft = CredentialStore.loadAPIKey() ?? ""
    @Published var lastTool = "None"
    @Published var toolLog: [String] = []
    @Published var rootHelperStatus = "Not checked"
    @Published var backgroundContinuation = UserDefaults.standard.object(forKey: "nextagent.backgroundContinuation") == nil ? true : UserDefaults.standard.bool(forKey: "nextagent.backgroundContinuation")
    @Published var backgroundState = "Idle"

    private static let currentToolSchemaVersion = "0.7.14-dualhud-bgdiag8"
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var activeTurnTask: Task<String, Error>?
    private var activeTurnID: UUID?
    private var activeReturnToApp = false
    private var progressStepCount = 0

    private let tools = DeviceToolRegistry()
    private lazy var client = OpenAIManagedAgentsClient(state: self, tools: tools)

    init() {
        let defaults = UserDefaults.standard
        if defaults.string(forKey: "nextagent.toolSchemaVersion") != Self.currentToolSchemaVersion {
            sessionId = ""
            defaults.removeObject(forKey: "nextagent.managedSessionId")
            defaults.removeObject(forKey: "nextagent.pendingTurn")
            defaults.removeObject(forKey: "nextagent.pendingBaselineAssistantId")
            defaults.set(Self.currentToolSchemaVersion, forKey: "nextagent.toolSchemaVersion")
            status = "Tool engine updated — new session ready"
        }
    }

    func saveSettings() {
        let trimmed = apiKeyDraft.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            CredentialStore.deleteAPIKey()
            status = "API key cleared"
        } else {
            let result = CredentialStore.saveAPIKey(trimmed)
            apiKeyDraft = CredentialStore.loadAPIKey() ?? trimmed
            if result.keychainSaved {
                status = "Settings saved securely"
            } else if result.fallbackSaved {
                status = "Settings saved (protected local fallback)"
            } else {
                status = "API key could not be saved (Keychain OSStatus \(result.keychainStatus))"
            }
        }
        UserDefaults.standard.set(sensitiveActions, forKey: "nextagent.sensitiveActions")
        UserDefaults.standard.set(backgroundContinuation, forKey: "nextagent.backgroundContinuation")
        UserDefaults.standard.synchronize()
    }

    func createOrRepairAgent() async {
        saveSettings()
        guard CredentialStore.loadAPIKey() != nil else {
            status = "API key required"
            return
        }
        busy = true
        defer { busy = false }
        do {
            try await client.validateConnection()
            status = "OpenAI connection ready"
        } catch {
            status = "Connection failed: \(error.localizedDescription)"
        }
    }

    func resetConversation() {
        sessionId = ""
        UserDefaults.standard.removeObject(forKey: "nextagent.managedSessionId")
        messages = [ChatMessage(role: "assistant", text: "Managed-agent session reset. Device tools and settings are unchanged.")]
        status = "Conversation reset"
    }

    func send() async {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !busy else { return }
        guard CredentialStore.loadAPIKey() != nil else {
            status = "API key missing"
            return
        }

        input = ""
        messages.append(ChatMessage(role: "user", text: text))
        busy = true
        status = "Agent working…"
        activeReturnToApp = shouldReturnToNextAgent(for: text)
        progressStepCount = 0
        publishProgress(state: "working", message: "Planning task…", progress: 0.05, returnToApp: activeReturnToApp)
        beginBackgroundTurnIfNeeded()

        let turnID = UUID()
        let turnTask = Task<String, Error> { [client] in
            try await client.runUserMessage(text)
        }
        activeTurnID = turnID
        activeTurnTask = turnTask

        defer {
            if activeTurnID == turnID {
                activeTurnTask = nil
                activeTurnID = nil
                busy = false
                endBackgroundTurn()
            }
        }

        do {
            let reply = try await turnTask.value
            guard activeTurnID == turnID else { return }
            messages.append(ChatMessage(role: "assistant", text: reply))
            status = "Ready"
            publishProgress(state: "complete", message: "Task complete", progress: 1.0, returnToApp: activeReturnToApp)
        } catch is CancellationError {
            if activeTurnID == turnID {
                status = "Stopped"
                publishProgress(state: "stopped", message: "Task stopped", progress: 1.0, returnToApp: false)
            }
        } catch {
            guard activeTurnID == turnID else { return }
            if backgroundContinuation && client.hasPendingTurn {
                status = "Turn paused — will resume automatically"
                backgroundState = "Pending"
                publishProgress(state: "working", message: "Waiting to resume…", progress: min(0.90, currentProgressEstimate()), returnToApp: activeReturnToApp)
            } else {
                messages.append(ChatMessage(role: "assistant", text: "Error: \(error.localizedDescription)"))
                status = "Failed"
                publishProgress(state: "failed", message: "Task failed", progress: 1.0, returnToApp: true)
            }
        }
    }

    func forceStop() {
        activeTurnTask?.cancel()
        activeTurnTask = nil
        activeTurnID = nil
        busy = false
        status = "Force stopped — next command will start a fresh session"
        backgroundState = "Idle"
        publishProgress(state: "stopped", message: "Force stopped", progress: 1.0, returnToApp: false)
        endBackgroundTurn()

        sessionId = ""
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: "nextagent.managedSessionId")
        defaults.removeObject(forKey: "nextagent.pendingTurn")
        defaults.removeObject(forKey: "nextagent.pendingBaselineAssistantId")

        messages.append(ChatMessage(role: "assistant", text: "Active task force-stopped. The next command will use a fresh tool session."))
    }

    func runLocalSelfTest() async {
        guard !busy else { return }
        busy = true
        status = "Running local tool self-test…"
        defer { busy = false }

        let pid = String(getpid())
        let protect = RootDaemonClient.request(action: "protect_pid", argument: pid)
        let protectStatus = RootDaemonClient.request(action: "protection_status")
        _ = RootDaemonClient.request(action: "unprotect_pid", argument: pid)

        let result = await tools.localSelfTest(allowSensitive: sensitiveActions)
        recordTool("local_self_test", result)
        let report = "Daemon background protector: \(protect.success ? "PASS" : "FAIL") | \(protectStatus.output) | Local tool self-test: \(result.output)"
        messages.append(ChatMessage(role: "assistant", text: report))
        status = result.success && protect.success ? "Local self-test complete" : "Local self-test found failures"
    }

    func handleBecameActive() async {
        guard backgroundContinuation else { return }
        for _ in 0..<20 {
            if !client.hasPendingTurn { backgroundState = "Idle"; return }
            if !busy { await resumePendingTurnIfNeeded(); return }
            try? await Task.sleep(nanoseconds: 500_000_000)
        }
    }

    func resumePendingTurnIfNeeded() async {
        guard backgroundContinuation, !busy, client.hasPendingTurn, !sessionId.isEmpty else { return }
        busy = true
        status = "Resuming background turn…"
        publishProgress(state: "working", message: "Resuming task…", progress: max(0.12, currentProgressEstimate()), returnToApp: activeReturnToApp)
        beginBackgroundTurnIfNeeded()

        let turnID = UUID()
        let turnTask = Task<String, Error> { [client] in
            try await client.resumePendingTurn()
        }
        activeTurnID = turnID
        activeTurnTask = turnTask

        defer {
            if activeTurnID == turnID {
                activeTurnTask = nil
                activeTurnID = nil
                busy = false
                endBackgroundTurn()
            }
        }

        do {
            let reply = try await turnTask.value
            guard activeTurnID == turnID else { return }
            messages.append(ChatMessage(role: "assistant", text: reply))
            status = "Ready"
            publishProgress(state: "complete", message: "Task complete", progress: 1.0, returnToApp: activeReturnToApp)
        } catch is CancellationError {
            if activeTurnID == turnID {
                status = "Stopped"
                publishProgress(state: "stopped", message: "Task stopped", progress: 1.0, returnToApp: false)
            }
        } catch {
            if activeTurnID == turnID {
                status = "Background turn pending"
                publishProgress(state: "working", message: "Waiting to resume…", progress: min(0.90, currentProgressEstimate()), returnToApp: activeReturnToApp)
            }
        }
    }

    private func beginBackgroundTurnIfNeeded() {
        guard backgroundContinuation else { return }

        let pid = String(getpid())
        let daemonPinned = RootDaemonClient.request(action: "protect_pid", argument: pid)
        let overlayStatus = RootDaemonClient.request(action: "overlay_status")
        let springBoardPinned = overlayStatus.success
            ? RootDaemonClient.request(action: "overlay_wait_pin", argument: pid)
            : ToolResult(success: false, output: overlayStatus.output)
        let localPinned = NABackgroundAssertionController.shared().start()
        let extended = BackgroundKeepAlive.shared.start()

        if springBoardPinned.success {
            backgroundState = "SpringBoard pinned"
        } else if daemonPinned.success {
            backgroundState = "Daemon pinned"
        } else if localPinned {
            backgroundState = "Pinned background"
        } else if extended {
            backgroundState = "Extended background"
        } else {
            backgroundState = "Protection unavailable"
        }

        if backgroundTask == .invalid {
            backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "NextAgentTurn") { [weak self] in
                Task { @MainActor in
                    guard let self else { return }
                    self.endUIKitBackgroundTaskOnly()

                    let overlayPin = RootDaemonClient.request(action: "overlay_wait_pin", argument: String(getpid()))
                    let daemonStatus = RootDaemonClient.request(action: "protection_status")
                    if overlayPin.success {
                        self.backgroundState = "SpringBoard pinned"
                    } else if daemonStatus.success {
                        self.backgroundState = "Daemon pinned"
                    } else if NABackgroundAssertionController.shared().isValid {
                        self.backgroundState = "Pinned background"
                    } else if BackgroundKeepAlive.shared.active {
                        self.backgroundState = "Extended background"
                    } else {
                        self.backgroundState = "Background protection lost"
                    }
                }
            }
        }
    }

    private func endUIKitBackgroundTaskOnly() {
        if backgroundTask != .invalid {
            UIApplication.shared.endBackgroundTask(backgroundTask)
            backgroundTask = .invalid
        }
    }

    private func endBackgroundTurn() {
        endUIKitBackgroundTaskOnly()
        _ = RootDaemonClient.request(action: "unprotect_pid", argument: String(getpid()))
        BackgroundKeepAlive.shared.stop()
        NABackgroundAssertionController.shared().stop()
        if !client.hasPendingTurn {
            backgroundState = "Idle"
        }
    }

    func checkRootHelper() {
        let result = RootDaemonClient.request(action: "ping")
        rootHelperStatus = result.success ? "Connected: \(result.output)" : "Unavailable: \(result.output)"
    }

    func toolStarted(_ name: String, arguments: [String: Any]) {
        progressStepCount += 1
        let label = progressLabel(for: name, arguments: arguments)
        publishProgress(
            state: "working",
            message: label,
            progress: currentProgressEstimate(),
            returnToApp: activeReturnToApp
        )
    }

    func recordTool(_ name: String, _ result: ToolResult) {
        lastTool = name
        let stamp = ISO8601DateFormatter().string(from: Date())
        toolLog.insert("\(stamp)  \(name)  \(result.success ? "OK" : "FAIL")  \(result.output.prefix(180))", at: 0)
        if toolLog.count > 100 { toolLog.removeLast(toolLog.count - 100) }

        let label = progressLabel(for: name, arguments: [:])
        publishProgress(
            state: "working",
            message: result.success ? "\(label) ✓" : "\(label) — retrying",
            progress: min(0.92, currentProgressEstimate() + 0.025),
            returnToApp: activeReturnToApp
        )
        if result.success {
            let completedStep = progressStepCount
            Task { @MainActor [weak self] in
                try? await Task.sleep(nanoseconds: 180_000_000)
                guard let self,
                      self.busy,
                      self.progressStepCount == completedStep else { return }
                self.publishProgress(
                    state: "working",
                    message: "Thinking…",
                    progress: min(0.94, self.currentProgressEstimate() + 0.03),
                    returnToApp: self.activeReturnToApp
                )
            }
        }
    }

    private func currentProgressEstimate() -> Double {
        min(0.90, 0.10 + Double(progressStepCount) * 0.085)
    }

    private func publishProgress(state progressState: String, message: String, progress: Double, returnToApp: Bool) {
        let payload: [String: Any] = [
            "state": progressState,
            "message": String(message.prefix(90)),
            "progress": max(0, min(1, progress)),
            "return_to_app": returnToApp,
            "pid": Int(getpid()),
            "updated_at": ISO8601DateFormatter().string(from: Date())
        ]
        guard JSONSerialization.isValidJSONObject(payload),
              let data = try? JSONSerialization.data(withJSONObject: payload),
              let text = String(data: data, encoding: .utf8) else { return }
        _ = RootDaemonClient.request(action: "progress", argument: text)
    }

    private func progressLabel(for name: String, arguments: [String: Any]) -> String {
        switch name {
        case "phone_apps":
            if let action = arguments["action"] as? String, action.hasPrefix("open") { return "Opening app…" }
            return "Checking apps…"
        case "phone_screen": return "Reading screen…"
        case "phone_input":
            if (arguments["action"] as? String) == "type_text" { return "Typing…" }
            return "Interacting…"
        case "phone_files": return "Working with files…"
        case "phone_packages": return "Managing package…"
        case "phone_services": return "Running system action…"
        case "phone_automation": return "Running automation…"
        case "phone_status": return "Checking device…"
        case "phone_clipboard": return "Updating clipboard…"
        case "phone_display": return "Updating display…"
        default: return "Agent working…"
        }
    }

    private func shouldReturnToNextAgent(for text: String) -> Bool {
        let lower = text.lowercased()
        if lower.contains("return to next agent") || lower.contains("come back to next agent") || lower.contains("return to the app") {
            return true
        }
        if lower.contains("stay in ") || lower.contains("leave me in ") || lower.contains("do not return") || lower.contains("don't return") {
            return false
        }

        let externalActions = [
            "open ", "launch ", "tap ", "press ", "swipe ", "type ",
            "write ", "create ", "send ", "set ", "change ", "install ",
            "remove ", "delete ", "play ", "pause ", "lock ", "respring"
        ]
        if externalActions.contains(where: { lower.contains($0) }) {
            return false
        }
        return true
    }

}

// MARK: - OpenAI Managed Agents API

final class OpenAIManagedAgentsClient {
    weak var state: AppState?
    let tools: DeviceToolRegistry
    private let base = URL(string: "https://api.openai.com/v1/agents/")!
    private let savedAgentId = "agent_a8bca3810e67406a8076559d2ba2e10f1379810a596e4d3082"
    private lazy var urlSession: URLSession = {
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = true
        config.timeoutIntervalForRequest = 120
        config.timeoutIntervalForResource = 300
        return URLSession(configuration: config)
    }()

    init(state: AppState, tools: DeviceToolRegistry) {
        self.state = state
        self.tools = tools
    }

    var hasPendingTurn: Bool { UserDefaults.standard.bool(forKey: "nextagent.pendingTurn") }

    private func markPending(baselineAssistantId: String?) {
        UserDefaults.standard.set(true, forKey: "nextagent.pendingTurn")
        if let baselineAssistantId { UserDefaults.standard.set(baselineAssistantId, forKey: "nextagent.pendingBaselineAssistantId") }
        else { UserDefaults.standard.removeObject(forKey: "nextagent.pendingBaselineAssistantId") }
    }

    private func clearPending() {
        UserDefaults.standard.set(false, forKey: "nextagent.pendingTurn")
        UserDefaults.standard.removeObject(forKey: "nextagent.pendingBaselineAssistantId")
    }

    private var apiKey: String {
        get throws {
            guard let k = CredentialStore.loadAPIKey(), !k.isEmpty else {
                throw NSError(domain: "NextAgent", code: 401, userInfo: [NSLocalizedDescriptionKey: "OpenAI API key is not configured"])
            }
            return k
        }
    }

    @MainActor
    func validateConnection() async throws {
        guard let state else { throw NSError(domain: "NextAgent", code: 1) }
        let agent = try await requestJSON(method: "GET", path: "/\(savedAgentId)")
        guard (agent["id"] as? String) == savedAgentId else {
            throw apiShape("Saved managed agent was not returned", agent)
        }
        let model = agent["model"] as? String ?? "unknown"
        guard model == "gpt-6-astra" else {
            throw NSError(domain: "NextAgent", code: 409, userInfo: [NSLocalizedDescriptionKey: "Managed agent currently uses \(model), expected gpt-6-astra"])
        }
        state.agentId = savedAgentId
        state.model = model
    }

    @MainActor
    func runUserMessage(_ message: String) async throws -> String {
        guard let state else { throw NSError(domain: "NextAgent", code: 2) }

        let baselineAssistantId: String?
        if state.sessionId.isEmpty {
            baselineAssistantId = nil
            let created = try await createSession(initialMessage: message)
            try Task.checkCancellation()
            guard let id = created["id"] as? String, !id.isEmpty else {
                throw apiShape("Managed session response had no session id", created)
            }
            state.sessionId = id
            UserDefaults.standard.set(id, forKey: "nextagent.managedSessionId")
        } else {
            baselineAssistantId = try await latestAssistantMessage(sessionId: state.sessionId)?.id
            try await sendUserMessage(sessionId: state.sessionId, text: message)
            try Task.checkCancellation()
        }

        markPending(baselineAssistantId: baselineAssistantId)
        return try await driveSession(sessionId: state.sessionId, baselineAssistantId: baselineAssistantId)
    }

    @MainActor
    func resumePendingTurn() async throws -> String {
        guard let state, !state.sessionId.isEmpty, hasPendingTurn else {
            throw NSError(domain: "NextAgent", code: 404, userInfo: [NSLocalizedDescriptionKey: "No pending managed-agent turn"])
        }
        let baseline = UserDefaults.standard.string(forKey: "nextagent.pendingBaselineAssistantId")
        return try await driveSession(sessionId: state.sessionId, baselineAssistantId: baseline)
    }

    private func createSession(initialMessage: String) async throws -> [String: Any] {
        let body: [String: Any] = [
            "agent_id": savedAgentId,
            "agent": ["tools": DeviceToolRegistry.toolSchemas],
            "environment": ["type": "none"],
            "input": initialMessage,
            "metadata": ["client": "NextAgent-iPhone", "client_version": "0.7.14"],
            "stream": false
        ]
        return try await requestJSON(method: "POST", path: "/sessions", body: body)
    }

    private func sendUserMessage(sessionId: String, text: String) async throws {
        let body: [String: Any] = [
            "events": [[
                "type": "agent.session.input.message",
                "input": [[
                    "role": "user",
                    "content": [["type": "input_text", "text": text]]
                ]]
            ]]
        ]
        _ = try await requestData(method: "POST", path: "/sessions/\(sessionId)/events", body: body)
    }

    @MainActor
    private func driveSession(sessionId: String, baselineAssistantId: String?) async throws -> String {
        guard let state else { throw NSError(domain: "NextAgent", code: 3) }
        for _ in 0..<240 {
            try Task.checkCancellation()
            let session = try await requestJSON(method: "GET", path: "/sessions/\(sessionId)")
            let status = session["status"] as? String ?? "unknown"

            if status == "failed" {
                clearPending()
                let reason = (session["error"] as? String) ?? "Managed agent session failed"
                throw NSError(domain: "NextAgent", code: 500, userInfo: [NSLocalizedDescriptionKey: reason])
            }

            if status == "requires_action" {
                let actions = parseRequiredActions(session)
                guard !actions.isEmpty else {
                    throw apiShape("Session requires action but supplied no supported function calls", session)
                }
                var events: [[String: Any]] = []
                for action in actions {
                    state.toolStarted(action.name, arguments: action.arguments)
                    let result = await tools.execute(action.name, arguments: action.arguments, allowSensitive: state.sensitiveActions)
                    state.recordTool(action.name, result)
                    var event: [String: Any] = [
                        "type": "agent.session.input.tool_result",
                        "turn_id": action.turnId,
                        "call_id": action.callId,
                        "success": result.success
                    ]
                    if result.success { event["output"] = result.output }
                    else { event["error"] = result.output }
                    events.append(event)
                }
                _ = try await requestData(method: "POST", path: "/sessions/\(sessionId)/events", body: ["events": events])
                continue
            }

            if status == "idle" {
                if let latest = try await latestAssistantMessage(sessionId: sessionId),
                   latest.id != baselineAssistantId,
                   !latest.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    clearPending()
                    return latest.text
                }
            }

            try await Task.sleep(nanoseconds: 500_000_000)
        }
        throw NSError(domain: "NextAgent", code: 408, userInfo: [NSLocalizedDescriptionKey: "Managed agent session timed out"])
    }

    private func parseRequiredActions(_ session: [String: Any]) -> [RequiredAction] {
        let raw = session["required_actions"] as? [[String: Any]] ?? []
        return raw.compactMap { item in
            guard (item["type"] as? String) == "function_call",
                  let turnId = item["turn_id"] as? String,
                  let callId = item["call_id"] as? String,
                  let name = item["name"] as? String else { return nil }
            let arguments: [String: Any]
            if let dict = item["arguments"] as? [String: Any] {
                arguments = dict
            } else if let rawString = item["arguments"] as? String,
                      let data = rawString.data(using: .utf8),
                      let obj = try? JSONSerialization.jsonObject(with: data),
                      let dict = obj as? [String: Any] {
                arguments = dict
            } else {
                arguments = [:]
            }
            return RequiredAction(turnId: turnId, callId: callId, name: name, arguments: arguments)
        }
    }

    private func latestAssistantMessage(sessionId: String) async throws -> (id: String, text: String)? {
        let json = try await requestJSON(method: "GET", path: "/sessions/\(sessionId)/items?limit=50&order=desc")
        let items = json["data"] as? [[String: Any]] ?? []
        for item in items {
            guard (item["type"] as? String) == "message",
                  (item["role"] as? String) == "assistant" else { continue }
            let id = item["id"] as? String ?? UUID().uuidString
            let content = item["content"] as? [[String: Any]] ?? []
            let text = content.compactMap { part -> String? in
                guard (part["type"] as? String) == "output_text" else { return nil }
                return part["text"] as? String
            }.joined(separator: "\n")
            if !text.isEmpty { return (id, text) }
        }
        return nil
    }

    private func requestJSON(method: String, path: String, body: [String: Any]? = nil) async throws -> [String: Any] {
        let data = try await requestData(method: method, path: path, body: body)
        guard !data.isEmpty else { return [:] }
        let obj = try JSONSerialization.jsonObject(with: data)
        guard let json = obj as? [String: Any] else {
            throw NSError(domain: "NextAgent", code: 422, userInfo: [NSLocalizedDescriptionKey: "Unexpected OpenAI managed-agent response"])
        }
        return json
    }

    private func requestData(method: String, path: String, body: [String: Any]? = nil) async throws -> Data {
        let key = try apiKey
        let relativePath = path.hasPrefix("/") ? String(path.dropFirst()) : path
        guard let url = URL(string: relativePath, relativeTo: base) else {
            throw NSError(domain: "NextAgent", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid Agents API URL"])
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.timeoutInterval = 120
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("agents=v1", forHTTPHeaderField: "OpenAI-Beta")
        if let body { req.httpBody = try JSONSerialization.data(withJSONObject: body) }
        var lastError: Error?
    for attempt in 0..<4 {
        do {
            let (data, response) = try await urlSession.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw NSError(domain: "NextAgent", code: 0) }
            guard (200..<300).contains(http.statusCode) else {
                let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
                throw NSError(domain: "NextAgent", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
            }
            return data
        } catch let e as URLError where [.networkConnectionLost, .timedOut, .notConnectedToInternet, .cannotConnectToHost, .cannotFindHost, .dnsLookupFailed].contains(e.code) {
            lastError = e
            if attempt < 3 {
                try? await Task.sleep(nanoseconds: UInt64(500_000_000 * (attempt + 1)))
                continue
            }
        } catch {
            throw error
        }
    }
    throw lastError ?? URLError(.networkConnectionLost)
    }

    private func apiShape(_ message: String, _ json: [String: Any]) -> NSError {
        NSError(domain: "NextAgent", code: 422, userInfo: [NSLocalizedDescriptionKey: "\(message): \(json)"])
    }
}

// MARK: - Device Tools

final class DeviceToolRegistry {
    static let agentInstructions = """
    You are Next Agent, controlling the user's own jailbroken iPhone through explicit local phone tools.

    The exposed tools are grouped routers:
    - phone_status: device/root/jailbreak/process/network/storage/battery/HID/package diagnostics and self_test.
    - phone_apps: list/open apps, open by display name, open sequences, and URLs.
    - phone_screen: capture/OCR/describe/find visible text/tap visible text/wait for text.
    - phone_input: tap, double tap, long press, swipe, type text, keyboard keys, hardware-style buttons, Home/Back, Control Center, Notification Center, wake and lock.
    - phone_files: root-visible list/read/info/search plus guarded create/write/copy/move/delete/zip/unzip.
    - phone_packages: package list/install/remove.
    - phone_services: launchd list/status/start/stop/restart plus uicache, respring, ldrestart, userspace reboot and process termination.
    - phone_automation: record/save/list/run/delete reusable flows or run immediate local multi-step sequences.
    - phone_clipboard: get/set clipboard text.
    - phone_display: get/set brightness.

    Use tools when the request requires phone interaction. Report only actual tool results and never claim success without a successful result.
              Opening an app is NOT completion when the user asked to do something inside that app. After opening the target app, continue the same turn with phone_screen and phone_input until every requested step is completed or a tool returns a real failure. For example, "open Notes, create a note, and type text" must continue after Notes launches: inspect the Notes screen, locate/create the note, focus the editor, type the requested text, then verify the visible result before reporting success.
              After opening an app, allow it a short moment to render, then use phone_screen action=describe/find_text before the next interaction. If screen vision fails, do not treat the app launch as task completion. Report the actual screen-capture/OCR failure. For Notes tasks, opening Notes alone is never success when the user also requested creating or typing a note.
              When phone_screen reports source=springboard_capture_failed_background or a real-screen bridge failure, stop coordinate interaction for that step and report the capture failure rather than guessing. A screenshot from Next Agent's own backgrounded window is never valid evidence of another foreground app.
              A phone_screen result is usable for coordinate planning only when its SpringBoard bridge reports success=true and quality.valid=true. Empty OCR is a real failure for text-driven UI steps such as Notes; do not guess a Compose button position after an empty OCR result.
              For any interactive task in another app, phone_apps open_name/open_bundle now automatically creates the split workspace; do not use the foreground_open_* actions unless the user explicitly asked to leave Next Agent and view only that app. After the split opens, use phone_screen OCR/describe/find_text before every coordinate-sensitive step. The OCR path is SpringBoard-native and must return actual text observations; do not treat a successful screenshot alone as vision success. Close the split workspace when the task is complete.
              Touch and keyboard actions are dispatched by the SpringBoard HID bridge. A successful dispatch is not proof that the UI changed: after type_text, tap, or press_key, verify the expected visible result with phone_screen/OCR before claiming completion. For typing diagnostics, the Next Agent composer itself is the first acceptance target before attempting Notes.
              For speed, when the target label is already known, use phone_screen find_text/tap_text directly instead of describe_screen followed by another OCR call. Prefer wait_text/wait_text_gone after an interaction instead of fixed sleeps or repeated full-screen descriptions. Routine navigation should use Fast OCR; use accurate OCR only when Fast OCR cannot resolve the requested text. Verify the requested final outcome once before reporting success; avoid redundant verification after it is confirmed.
              When the user explicitly asks to navigate through an app UI (for example Settings → General → About), that visible UI route is part of the requested task. If a requested screen or row cannot be opened, do not substitute phone_status/device_info or another diagnostic source and then claim the UI task succeeded. Diagnostic tools may be used only to troubleshoot or provide clearly labeled secondary information; report the requested UI route as incomplete until the visible destination is reached and verified. phone_screen tap_text uses Accurate OCR for the actual tap target even though read/find/wait operations remain optimized for speed.
              Task status is provided by a dual HUD stack: native SpringBoard HUD when available, otherwise a foreground-app HUD injected into the currently active UIKit app. Do not treat native HUD unavailability by itself as task failure.
    Prefer phone_screen describe/find_text before guessing coordinates. For multi-step UI control, prefer phone_automation action=run_steps so steps execute locally while another app is foregrounded.
    Never request, reveal, type, store or inspect passwords, passcodes, authentication tokens, private keys, banking/payment credentials, Keychain contents, or private communications.
    Do not tap purchase, payment, send, authentication, delete, package install/remove, root write/delete, service changes, respring/ldrestart/userspace reboot, lock/power, or similarly consequential controls unless the user explicitly authorized that exact action in the current request.
    If Sensitive Actions are disabled, explain that the user can enable them in Next Agent Settings; do not bypass the switch.
    Keep user-visible replies compact and phone-friendly. Avoid wide Markdown tables and fenced code blocks unless explicitly requested.
    """

    static let baseToolSchemas: [[String: Any]] = [
        tool("device_info", "Get device, OS, jailbreak/root, root-helper and filesystem status.", [:]),
        tool("root_helper_status", "Check whether the separately installed nextagentd privileged helper is connected and actually running as root.", [:]),
        tool("jailbreak_diagnostics", "Inspect jailbreak/bootstrap paths using the root helper when installed. Read-only.", [:]),
        tool("root_list_files", "List a root-visible directory through nextagentd. Credential stores and private communications roots are blocked by the daemon.", ["path": str("Absolute directory path")], required: ["path"]),
        tool("root_read_text_file", "Read a root-visible UTF-8 text file through nextagentd, up to 256 KB. Credential stores and private communications roots are blocked.", ["path": str("Absolute text file path")], required: ["path"]),
        tool("list_installed_apps", "List installed iOS applications with display name and bundle identifier.", [:]),
        tool("open_url", "Open an http/https or iOS URL scheme on the phone.", ["url": str("URL to open")], required: ["url"]),
        tool("open_app", "Open one installed app by bundle identifier using LaunchServices when available.", ["bundle_id": str("Bundle identifier")], required: ["bundle_id"]),
        tool("open_apps_sequence", "Open multiple installed apps in one background-safe sequence. Always use this for requests involving two or more apps.", ["bundle_ids": ["type": "array", "items": ["type": "string"], "minItems": 2, "maxItems": 10, "description": "Bundle identifiers in opening order"], "delay_seconds": num("Delay between launches, 0.5 to 5 seconds")], required: ["bundle_ids"]),
        tool("clipboard_get", "Read the current general pasteboard text.", [:]),
        tool("clipboard_set", "Replace the general pasteboard text.", ["text": str("Text to put on the clipboard")], required: ["text"]),
        tool("list_files", "List files in an allowed user path. Paths under /var/mobile and the app container are supported when the install has access.", ["path": str("Directory path")], required: ["path"]),
        tool("read_text_file", "Read a UTF-8 text file from an allowed user path. Large files are truncated.", ["path": str("File path")], required: ["path"]),
        tool("write_text_file", "Write UTF-8 text to an allowed user path. Sensitive actions must be enabled.", ["path": str("File path"), "text": str("Text to write")], required: ["path", "text"]),
        tool("process_list", "List running processes through the root helper without relying on a shell.", [:]),
        tool("network_interfaces", "Show local network interface addresses without contacting external services.", [:]),
        tool("device_storage", "Show filesystem capacity and free space through the root helper.", [:]),
        tool("get_brightness", "Get the current screen brightness from 0 to 1.", [:]),
        tool("set_brightness", "Set the current screen brightness from 0 to 1.", ["value": num("Brightness between 0 and 1")], required: ["value"]),
        tool("take_screenshot", "Attempt a full-device screenshot using available jailbreak screenshot utilities and save it under /var/mobile/Documents/NextAgent.", [:]),
        tool("refresh_icon_cache", "Run uicache to refresh app icons. Sensitive actions must be enabled.", [:]),
        tool("respring", "Respring SpringBoard. This interrupts the UI. Sensitive actions must be enabled.", [:]),
        tool("terminate_process", "Terminate a process by numeric PID. Sensitive actions must be enabled.", ["pid": int("Process ID")], required: ["pid"])
    ]

    static var toolSchemas: [[String: Any]] { V071ToolSchemas.grouped }

    private static func tool(_ name: String, _ description: String, _ props: [String: Any], required: [String] = []) -> [String: Any] {
        [
            "type": "function",
            "name": name,
            "description": description,
            "parameters": [
                "type": "object",
                "properties": props,
                "required": required,
                "additionalProperties": false
            ]
        ]
    }
    private static func str(_ d: String) -> [String: Any] { ["type": "string", "description": d] }
    private static func num(_ d: String) -> [String: Any] { ["type": "number", "description": d] }
    private static func int(_ d: String) -> [String: Any] { ["type": "integer", "description": d] }

    @MainActor
    func execute(_ name: String, arguments: [String: Any], allowSensitive: Bool) async -> ToolResult {
        AutomationRecorder.shared.record(tool: name, arguments: arguments)
        switch name {
        case "device_info": return deviceInfo()
        case "root_helper_status": return RootDaemonClient.request(action: "ping")
        case "jailbreak_diagnostics": return RootDaemonClient.request(action: "jailbreak_info")
        case "root_list_files":
            guard let path = arguments["path"] as? String else { return badArgs() }
            return RootDaemonClient.request(action: "list", argument: path)
        case "root_read_text_file":
            guard let path = arguments["path"] as? String else { return badArgs() }
            return RootDaemonClient.request(action: "read", argument: path)
        case "list_installed_apps": return listApps()
        case "open_url": return openURL(arguments)
        case "open_app": return openApp(arguments)
        case "open_apps_sequence": return await openAppsSequence(arguments)
        case "clipboard_get": return ToolResult(success: true, output: UIPasteboard.general.string ?? "")
        case "clipboard_set":
            guard let text = arguments["text"] as? String else { return badArgs() }
            UIPasteboard.general.string = text
            return ToolResult(success: true, output: "Clipboard updated")
        case "list_files": return listFiles(arguments)
        case "read_text_file": return readText(arguments)
        case "write_text_file":
            guard allowSensitive else { return sensitiveOff() }
            return writeText(arguments)
        case "process_list":
            let privileged = RootDaemonClient.request(action: "ps")
            return privileged.success ? privileged : ShellRunner.runPreset("ps -axo pid,user,comm | head -n 250")
        case "network_interfaces": return ShellRunner.runPreset("ifconfig 2>/dev/null || ip addr 2>/dev/null")
        case "device_storage":
            let privileged = RootDaemonClient.request(action: "storage")
            return privileged.success ? privileged : ToolResult(success: false, output: "Root storage diagnostic failed: \(privileged.output)")
        case "get_brightness": return ToolResult(success: true, output: String(format: "%.3f", UIScreen.main.brightness))
        case "set_brightness":
            guard let v = arguments["value"] as? NSNumber else { return badArgs() }
            UIScreen.main.brightness = CGFloat(max(0, min(1, v.doubleValue)))
            return ToolResult(success: true, output: "Brightness set to \(UIScreen.main.brightness)")
        case "take_screenshot": return screenshot()
        case "refresh_icon_cache":
            guard allowSensitive else { return sensitiveOff() }
            let daemon = RootDaemonClient.request(action: "uicache")
            return daemon.success ? daemon : ShellRunner.runRootPreset("uicache -a 2>&1")
        case "respring":
            guard allowSensitive else { return sensitiveOff() }
            let daemon = RootDaemonClient.request(action: "respring")
            return daemon.success ? daemon : ShellRunner.runRootPreset("(command -v sbreload >/dev/null && sbreload) || killall SpringBoard")
        case "terminate_process":
            guard allowSensitive else { return sensitiveOff() }
            guard let pid = (arguments["pid"] as? NSNumber)?.intValue, pid > 20 else { return badArgs() }
            let daemon = RootDaemonClient.request(action: "kill", argument: String(pid))
            return daemon.success ? daemon : ShellRunner.runRootPreset("kill -TERM \(pid)")
        default:
            if let router = await executeV071(name, arguments: arguments, allowSensitive: allowSensitive) {
                return router
            }
            if let v07 = await executeV07(name, arguments: arguments, allowSensitive: allowSensitive) {
                return v07
            }
            if let v05 = await executeV05(name, arguments: arguments, allowSensitive: allowSensitive) {
                return v05
            }
            return ToolResult(success: false, output: "Unknown tool: \(name)")
        }
    }

    private func deviceInfo() -> ToolResult {
        var uts = utsname(); uname(&uts)
        let machineCapacity = MemoryLayout.size(ofValue: uts.machine)
        let machine = withUnsafePointer(to: &uts.machine) { p in
            p.withMemoryRebound(to: CChar.self, capacity: machineCapacity) { String(cString: $0) }
        }
        let roots = ["/var/jb", "/Applications", "/private/preboot"]
        let present = roots.filter { FileManager.default.fileExists(atPath: $0) }
        var info: [String: Any] = [
            "name": UIDevice.current.name,
            "model": UIDevice.current.model,
            "machine": machine,
            "system": UIDevice.current.systemName,
            "version": UIDevice.current.systemVersion,
            "uid": getuid(),
            "euid": geteuid(),
            "jailbreak_paths": present,
            "bundle": Bundle.main.bundleIdentifier ?? ""
        ]
        let daemon = RootDaemonClient.request(action: "ping")
        if daemon.success,
           let data = daemon.output.data(using: .utf8),
           let obj = try? JSONSerialization.jsonObject(with: data) {
            info["root_helper"] = obj
        } else {
            info["root_helper"] = ["connected": false, "detail": daemon.output]
        }
        return jsonResult(info)
    }

    private func listApps() -> ToolResult {
        guard let cls = NSClassFromString("LSApplicationWorkspace") else {
            return ToolResult(success: false, output: "LaunchServices is unavailable on this install")
        }
        let classObject: AnyObject = cls as AnyObject
        guard let unmanaged = classObject.perform(NSSelectorFromString("defaultWorkspace")),
              let ws = unmanaged.takeUnretainedValue() as? NSObject,
              let appsValue = ws.perform(NSSelectorFromString("allInstalledApplications"))?.takeUnretainedValue(),
              let apps = appsValue as? [NSObject] else {
            return ToolResult(success: false, output: "LaunchServices app enumeration is unavailable on this install")
        }
        var rows: [[String: String]] = []
        for app in apps.prefix(500) {
            let bid = app.value(forKey: "applicationIdentifier") as? String ?? ""
            let name = app.value(forKey: "localizedName") as? String ?? app.value(forKey: "itemName") as? String ?? bid
            if !bid.isEmpty { rows.append(["name": name, "bundle_id": bid]) }
        }
        rows.sort { ($0["name"] ?? "") < ($1["name"] ?? "") }
        return jsonResult(["count": rows.count, "apps": rows])
    }

    private func openApp(_ args: [String: Any]) -> ToolResult {
        guard let bid = args["bundle_id"] as? String, !bid.isEmpty else { return badArgs() }
        guard let cls = NSClassFromString("LSApplicationWorkspace") else {
            return ToolResult(success: false, output: "LaunchServices unavailable")
        }
        let classObject: AnyObject = cls as AnyObject
        guard let unmanaged = classObject.perform(NSSelectorFromString("defaultWorkspace")),
              let ws = unmanaged.takeUnretainedValue() as? NSObject else {
            return ToolResult(success: false, output: "LaunchServices unavailable")
        }
        let sel = NSSelectorFromString("openApplicationWithBundleID:")
        guard ws.responds(to: sel) else { return ToolResult(success: false, output: "App launch selector unavailable") }
        _ = ws.perform(sel, with: bid)
        return ToolResult(success: true, output: "Launch request sent for \(bid)")
    }

    @MainActor
    private func openAppsSequence(_ args: [String: Any]) async -> ToolResult {
        guard let bundleIDs = args["bundle_ids"] as? [String], bundleIDs.count >= 2, bundleIDs.count <= 10 else { return badArgs() }
        let delay = max(0.5, min(5.0, (args["delay_seconds"] as? NSNumber)?.doubleValue ?? 1.5))
        var opened: [String] = []
        var failures: [String] = []
        for (index, bid) in bundleIDs.enumerated() {
            let result = openApp(["bundle_id": bid])
            if result.success { opened.append(bid) } else { failures.append("\(bid): \(result.output)") }
            if index < bundleIDs.count - 1 {
                try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            }
        }
        let payload: [String: Any] = ["requested": bundleIDs, "opened": opened, "failures": failures, "delay_seconds": delay]
        return jsonResult(payload)
    }

    private func openURL(_ args: [String: Any]) -> ToolResult {
        guard let s = args["url"] as? String, let url = URL(string: s) else { return badArgs() }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        return ToolResult(success: true, output: "Open request sent for \(s)")
    }

    private func allowedPath(_ raw: String) -> String? {
        let p = (raw as NSString).standardizingPath
        let home = NSHomeDirectory()
        if p == "/var/mobile" || p.hasPrefix("/var/mobile/") || p == home || p.hasPrefix(home + "/") { return p }
        return nil
    }

    private func listFiles(_ args: [String: Any]) -> ToolResult {
        guard let raw = args["path"] as? String, let p = allowedPath(raw) else { return ToolResult(success: false, output: "Path is outside allowed user roots") }
        do {
            let rows = try FileManager.default.contentsOfDirectory(atPath: p).prefix(500).map { name -> [String: Any] in
                let full = (p as NSString).appendingPathComponent(name)
                let attrs = try? FileManager.default.attributesOfItem(atPath: full)
                return ["name": name, "directory": (attrs?[.type] as? FileAttributeType) == .typeDirectory, "size": attrs?[.size] as? NSNumber ?? 0]
            }
            return jsonResult(["path": p, "items": Array(rows)])
        } catch { return ToolResult(success: false, output: error.localizedDescription) }
    }

    private func readText(_ args: [String: Any]) -> ToolResult {
        guard let raw = args["path"] as? String, let p = allowedPath(raw) else { return ToolResult(success: false, output: "Path is outside allowed user roots") }
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: p), options: [.mappedIfSafe])
            let clipped = data.prefix(250_000)
            guard let text = String(data: clipped, encoding: .utf8) else { return ToolResult(success: false, output: "File is not UTF-8 text") }
            return ToolResult(success: true, output: text + (data.count > clipped.count ? "\n[truncated]" : ""))
        } catch { return ToolResult(success: false, output: error.localizedDescription) }
    }

    private func writeText(_ args: [String: Any]) -> ToolResult {
        guard let raw = args["path"] as? String, let p = allowedPath(raw), let text = args["text"] as? String else { return badArgs() }
        do {
            try FileManager.default.createDirectory(at: URL(fileURLWithPath: (p as NSString).deletingLastPathComponent), withIntermediateDirectories: true)
            try text.write(toFile: p, atomically: true, encoding: .utf8)
            return ToolResult(success: true, output: "Wrote \(text.utf8.count) bytes to \(p)")
        } catch { return ToolResult(success: false, output: error.localizedDescription) }
    }

    private func screenshot() -> ToolResult {
        let dir = "/var/mobile/Documents/NextAgent"
        try? FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true)
        let file = "\(dir)/screenshot-\(Int(Date().timeIntervalSince1970)).png"
        let candidates = [
            "screencapture -x '\(file)'",
            "/usr/bin/screencapture -x '\(file)'",
            "/var/jb/usr/bin/screencapture -x '\(file)'"
        ]
        for command in candidates {
            let result = ShellRunner.runRootPreset(command)
            if result.success && FileManager.default.fileExists(atPath: file) {
                return ToolResult(success: true, output: file)
            }
        }
        return ToolResult(success: false, output: "No compatible full-device screenshot utility was found")
    }

    private func jsonResult(_ obj: Any) -> ToolResult {
        guard JSONSerialization.isValidJSONObject(obj), let data = try? JSONSerialization.data(withJSONObject: obj, options: [.prettyPrinted]), let text = String(data: data, encoding: .utf8) else {
            return ToolResult(success: false, output: "Could not serialize result")
        }
        return ToolResult(success: true, output: text)
    }
    private func badArgs() -> ToolResult { ToolResult(success: false, output: "Invalid or missing arguments") }
    private func sensitiveOff() -> ToolResult { ToolResult(success: false, output: "Sensitive actions are disabled in Next Agent Settings") }
}


// MARK: - Privileged helper client

enum RootDaemonClient {
    private static let host = "127.0.0.1"
    private static let port: UInt16 = 37589
    private static let tokenPaths = [
        "/var/mobile/Library/NextAgent/daemon.token",
        "/private/var/mobile/Library/NextAgent/daemon.token"
    ]

    static func request(action: String, argument: String = "") -> ToolResult {
        guard action.range(of: "^[a-z_]+$", options: .regularExpression) != nil else {
            return ToolResult(success: false, output: "Invalid daemon action")
        }
        let tokenLoad = loadToken()
        guard let rawToken = tokenLoad.token else {
            return ToolResult(success: false, output: "Root helper token is unavailable. " + tokenLoad.detail)
        }
        let token = rawToken.trimmingCharacters(in: .whitespacesAndNewlines)
        guard token.count == 64 else { return ToolResult(success: false, output: "Root helper token is invalid") }

        let fd = Darwin.socket(AF_INET, SOCK_STREAM, 0)
        guard fd >= 0 else { return ToolResult(success: false, output: "socket failed: \(String(cString: strerror(errno)))") }
        defer { Darwin.close(fd) }

        var tv = timeval(tv_sec: 3, tv_usec: 0)
        _ = withUnsafePointer(to: &tv) { p in
            Darwin.setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, p, socklen_t(MemoryLayout<timeval>.size))
        }
        _ = withUnsafePointer(to: &tv) { p in
            Darwin.setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, p, socklen_t(MemoryLayout<timeval>.size))
        }

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = in_port_t(port.bigEndian)
        let ipResult = host.withCString { inet_pton(AF_INET, $0, &addr.sin_addr) }
        guard ipResult == 1 else { return ToolResult(success: false, output: "inet_pton failed") }
        let connected = withUnsafePointer(to: &addr) { p in
            p.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                Darwin.connect(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard connected == 0 else {
            return ToolResult(success: false, output: "Root helper is not listening on 127.0.0.1:\(port): \(String(cString: strerror(errno)))")
        }

        let encoded = Data(argument.utf8).base64EncodedString()
        let line = "NAGENT1 \(token) \(action) \(encoded.isEmpty ? "-" : encoded)\n"
        guard writeAll(fd: fd, data: Data(line.utf8)) else {
            return ToolResult(success: false, output: "Failed to send request to root helper")
        }
        guard let header = readLine(fd: fd, max: 128) else {
            return ToolResult(success: false, output: "Root helper did not return a response header")
        }
        let parts = header.split(separator: " ", maxSplits: 1).map(String.init)
        guard parts.count == 2, let count = Int(parts[1]), count >= 0, count <= 524_288 else {
            return ToolResult(success: false, output: "Malformed root helper response")
        }
        guard let data = readExact(fd: fd, count: count) else {
            return ToolResult(success: false, output: "Incomplete root helper response")
        }
        let output = String(data: data, encoding: .utf8) ?? "[non-UTF8 daemon output]"
        return ToolResult(success: parts[0] == "OK", output: output)
    }

    private static func loadToken() -> (token: String?, detail: String) {
        var diagnostics: [String] = []
        for path in tokenPaths {
            errno = 0
            let fd = Darwin.open(path, O_RDONLY)
            if fd < 0 {
                diagnostics.append("\(path): open failed errno=\(errno) (\(String(cString: strerror(errno))))")
                continue
            }

            var buffer = [UInt8](repeating: 0, count: 128)
            errno = 0
            let n = Darwin.read(fd, &buffer, buffer.count - 1)
            let readErrno = errno
            Darwin.close(fd)

            if n <= 0 {
                diagnostics.append("\(path): read failed errno=\(readErrno) (\(String(cString: strerror(readErrno))))")
                continue
            }
            let data = Data(buffer.prefix(Int(n)))
            guard let text = String(data: data, encoding: .utf8) else {
                diagnostics.append("\(path): token was not UTF-8")
                continue
            }
            let token = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if token.count == 64 {
                return (token, "read from \(path)")
            }
            diagnostics.append("\(path): unexpected token length \(token.count)")
        }
        return (nil, diagnostics.joined(separator: " | "))
    }

    private static func writeAll(fd: Int32, data: Data) -> Bool {
        var sent = 0
        return data.withUnsafeBytes { raw in
            guard let base = raw.baseAddress else { return false }
            while sent < data.count {
                let n = Darwin.write(fd, base.advanced(by: sent), data.count - sent)
                if n <= 0 { return false }
                sent += n
            }
            return true
        }
    }

    private static func readLine(fd: Int32, max: Int) -> String? {
        var bytes: [UInt8] = []
        bytes.reserveCapacity(min(max, 128))
        while bytes.count < max {
            var byte: UInt8 = 0
            let n = Darwin.read(fd, &byte, 1)
            if n <= 0 { return nil }
            if byte == 10 { break }
            bytes.append(byte)
        }
        return String(bytes: bytes, encoding: .utf8)
    }

    private static func readExact(fd: Int32, count: Int) -> Data? {
        if count == 0 { return Data() }
        var data = Data(count: count)
        var readCount = 0
        let ok = data.withUnsafeMutableBytes { raw -> Bool in
            guard let base = raw.baseAddress else { return false }
            while readCount < count {
                let n = Darwin.read(fd, base.advanced(by: readCount), count - readCount)
                if n <= 0 { return false }
                readCount += n
            }
            return true
        }
        return ok ? data : nil
    }
}

// MARK: - Shell

enum ShellRunner {
    static func runPreset(_ command: String) -> ToolResult { run(shell: bestShell(), command: command) }

    static func runRootPreset(_ command: String) -> ToolResult {
        if geteuid() == 0 { return run(shell: bestShell(), command: command) }
        let sudoCandidates = ["/var/jb/usr/bin/sudo", "/usr/bin/sudo", "/bin/sudo"]
        for sudo in sudoCandidates where FileManager.default.isExecutableFile(atPath: sudo) {
            let result = spawn(sudo, [sudo, "-n", bestShell(), "-c", command])
            if result.0 == 0 { return ToolResult(success: true, output: result.1) }
        }
        let plain = run(shell: bestShell(), command: command)
        if plain.success { return plain }
        return ToolResult(success: false, output: "Root command failed. UID=\(geteuid()). Configure passwordless sudo/root helper for the jailbreak if root-only actions are required. \(plain.output)")
    }

    private static func bestShell() -> String {
        ["/var/jb/bin/sh", "/bin/sh"].first(where: { FileManager.default.isExecutableFile(atPath: $0) }) ?? "/bin/sh"
    }

    private static func run(shell: String, command: String) -> ToolResult {
        let (code, output) = spawn(shell, [shell, "-c", command])
        return ToolResult(success: code == 0, output: output.isEmpty ? "exit=\(code)" : output)
    }

    private static func spawn(_ path: String, _ argvStrings: [String]) -> (Int32, String) {
        var pipefd: [Int32] = [0, 0]
        guard pipe(&pipefd) == 0 else { return (errno, "pipe failed") }
        defer { close(pipefd[0]) }

        var actions: posix_spawn_file_actions_t? = nil
        posix_spawn_file_actions_init(&actions)
        posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, pipefd[0])

        var argv = argvStrings.map { strdup($0) }
        argv.append(nil)
        defer { argv.forEach { if let p = $0 { free(p) } } }

        var pid: pid_t = 0
        let rc: Int32 = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, path, &actions, nil, buffer.baseAddress, environ)
        }
        posix_spawn_file_actions_destroy(&actions)
        close(pipefd[1])
        if rc != 0 { return (rc, String(cString: strerror(rc))) }

        var data = Data()
        var buffer = [UInt8](repeating: 0, count: 4096)
        while true {
            let n = read(pipefd[0], &buffer, buffer.count)
            if n <= 0 { break }
            data.append(contentsOf: buffer.prefix(Int(n)))
            if data.count > 500_000 { break }
        }
        var status: Int32 = 0
        waitpid(pid, &status, 0)
        let exitCode: Int32 = (status & 0x7f) == 0 ? ((status >> 8) & 0xff) : -1
        let output = String(data: data, encoding: .utf8) ?? ""
        return (exitCode, output)
    }
}

// MARK: - Credential persistence

struct CredentialSaveResult {
    let keychainSaved: Bool
    let keychainStatus: OSStatus
    let fallbackSaved: Bool
}

enum KeychainStore {
    private static let service = "uk.zeshanbarvi.nextagent.credentials"

    @discardableResult
    static func save(_ value: String, key: String) -> OSStatus {
        let data = Data(value.utf8)
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: key
        ]
        let attributes: [CFString: Any] = [
            kSecValueData: data,
            kSecAttrAccessible: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let updateStatus = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if updateStatus == errSecSuccess { return updateStatus }
        if updateStatus != errSecItemNotFound { return updateStatus }

        var add = query
        add[kSecValueData] = data
        add[kSecAttrAccessible] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(add as CFDictionary, nil)
    }

    static func load(_ key: String) -> (String?, OSStatus) {
        var item: CFTypeRef?
        let status = SecItemCopyMatching([
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: key,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ] as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else { return (nil, status) }
        return (String(data: data, encoding: .utf8), status)
    }

    @discardableResult
    static func delete(_ key: String) -> OSStatus {
        SecItemDelete([
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: key
        ] as CFDictionary)
    }
}

enum CredentialStore {
    private static let account = "openai_api_key"

    private static var fallbackURL: URL? {
        do {
            let root = try FileManager.default.url(for: .applicationSupportDirectory,
                                                   in: .userDomainMask,
                                                   appropriateFor: nil,
                                                   create: true)
            let dir = root.appendingPathComponent("NextAgent", isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true,
                                                    attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
            return dir.appendingPathComponent("openai-project-key.bin")
        } catch {
            return nil
        }
    }

    static func saveAPIKey(_ value: String) -> CredentialSaveResult {
        let keychainStatus = KeychainStore.save(value, key: account)
        let keychainSaved = keychainStatus == errSecSuccess
        var fallbackSaved = false
        if let url = fallbackURL, let data = value.data(using: .utf8) {
            do {
                try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
                fallbackSaved = true
            } catch {
                fallbackSaved = false
            }
        }
        return CredentialSaveResult(keychainSaved: keychainSaved,
                                    keychainStatus: keychainStatus,
                                    fallbackSaved: fallbackSaved)
    }

    static func loadAPIKey() -> String? {
        let (keychainValue, _) = KeychainStore.load(account)
        if let keychainValue, !keychainValue.isEmpty { return keychainValue }
        guard let url = fallbackURL,
              let data = try? Data(contentsOf: url),
              let value = String(data: data, encoding: .utf8),
              !value.isEmpty else { return nil }
        return value
    }

    static func deleteAPIKey() {
        _ = KeychainStore.delete(account)
        if let url = fallbackURL { try? FileManager.default.removeItem(at: url) }
    }
}

// MARK: - UI

struct RootView: View {
    @EnvironmentObject var state: AppState
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        TabView {
            ChatView().tabItem { Label("Agent", systemImage: "sparkles") }
            ToolsView().tabItem { Label("Tools", systemImage: "wrench.and.screwdriver") }
            SettingsView().tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .tint(.primary)
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                Task { await state.handleBecameActive() }
            } else if phase == .background && state.busy {
                state.backgroundState = "Background"
            }
        }
    }
}

struct ChatView: View {
    @EnvironmentObject var state: AppState

    private func attributed(_ text: String) -> AttributedString {
        (try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }

    private func copy(_ text: String) {
        UIPasteboard.general.string = text
        state.status = "Copied"
    }

    private func pasteIntoComposer() {
        guard let clip = UIPasteboard.general.string, !clip.isEmpty else { return }
        if state.input.isEmpty { state.input = clip }
        else { state.input += (state.input.hasSuffix(" ") || state.input.hasSuffix("\n") ? "" : " ") + clip }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    Circle().frame(width: 8, height: 8).opacity(state.busy ? 0.45 : 1)
                    Text(state.status).font(.caption).lineLimit(1)
                    if state.backgroundState != "Idle" {
                        Text(state.backgroundState).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer()
                    if !state.lastTool.isEmpty { Text("Tool: \(state.lastTool)").font(.caption2).foregroundStyle(.secondary) }
                }.padding(.horizontal).padding(.vertical, 8)

                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 10) {
                            ForEach(state.messages) { m in
                                HStack(alignment: .bottom) {
                                    if m.role == "assistant" {
                                        VStack(alignment: .leading, spacing: 8) {
                                            Text(attributed(m.text))
                                                .textSelection(.enabled)
                                            HStack(spacing: 12) {
                                                Button { copy(m.text) } label: {
                                                    Label("Copy", systemImage: "doc.on.doc")
                                                }
                                                .font(.caption)
                                                .buttonStyle(.plain)
                                                Spacer()
                                            }
                                        }
                                        .padding(10)
                                        .background(.thinMaterial)
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                        .contextMenu {
                                            Button("Copy response") { copy(m.text) }
                                        }
                                        Spacer(minLength: 35)
                                    } else {
                                        Spacer(minLength: 35)
                                        Text(m.text)
                                            .textSelection(.enabled)
                                            .padding(10)
                                            .foregroundStyle(.white)
                                            .background(.black)
                                            .clipShape(RoundedRectangle(cornerRadius: 12))
                                            .contextMenu {
                                                Button("Copy prompt") { copy(m.text) }
                                            }
                                    }
                                }.id(m.id)
                            }
                        }.padding()
                    }
                    .onChange(of: state.messages.count) { _ in if let id = state.messages.last?.id { proxy.scrollTo(id, anchor: .bottom) } }
                }

                Divider()
                HStack(alignment: .bottom, spacing: 8) {
                    Button(action: pasteIntoComposer) {
                        Image(systemName: "doc.on.clipboard")
                            .frame(width: 28, height: 32)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Paste from clipboard")

                    TextField("Ask Next Agent to inspect or control this iPhone…", text: $state.input, axis: .vertical)
                        .textFieldStyle(.roundedBorder).lineLimit(1...5)
                    Button {
                        Task { await state.send() }
                    } label: {
                        if state.busy { ProgressView().frame(width: 32, height: 32) }
                        else { Image(systemName: "arrow.up.circle.fill").font(.system(size: 30)) }
                    }.disabled(state.busy || state.input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }.padding()
            }
            .navigationTitle("Next Agent")
        }
    }
}

struct ToolsView: View {
    @EnvironmentObject var state: AppState
    var body: some View {
        NavigationStack {
            List {
                Section("Runtime") {
                    LabeledContent("UID", value: "\(getuid())")
                    LabeledContent("EUID", value: "\(geteuid())")
                    LabeledContent("Root helper", value: state.rootHelperStatus)
                    LabeledContent("Background turn", value: state.backgroundState)
                    Button("Test Root Helper") { state.checkRootHelper() }
                    LabeledContent("Sensitive actions", value: state.sensitiveActions ? "Enabled" : "Disabled")
                    LabeledContent("Last tool", value: state.lastTool)
                }
                Section("Available to the agent") {
                    ForEach(["Device info", "Root helper status", "Root jailbreak diagnostics", "Root file listing / text reads", "Installed apps", "Open app / URL", "Clipboard", "User files", "Processes", "Network interfaces", "Storage", "Brightness", "Screenshot attempt", "uicache*", "Respring*", "Terminate process*"], id: \.self) { Text($0) }
                    Text("* requires Sensitive actions in Settings").font(.caption).foregroundStyle(.secondary)
                }
                Section("Tool log") {
                    if state.toolLog.isEmpty { Text("No tool calls yet").foregroundStyle(.secondary) }
                    ForEach(state.toolLog, id: \.self) { Text($0).font(.caption.monospaced()).textSelection(.enabled) }
                }
            }.navigationTitle("Device Tools")
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var state: AppState
    @State private var revealKey = false
    var body: some View {
        NavigationStack {
            Form {
                Section("OpenAI") {
                    if revealKey {
                        TextField("API key", text: $state.apiKeyDraft).textInputAutocapitalization(.never).autocorrectionDisabled()
                    } else {
                        SecureField("API key", text: $state.apiKeyDraft).textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Toggle("Show key", isOn: $revealKey)
                    LabeledContent("Model", value: state.model)
                    Text("Model and reasoning are controlled by the saved managed-agent definition.").font(.caption).foregroundStyle(.secondary)
                    Button("Save Settings") { state.saveSettings() }
                }

                Section("OpenAI Connection") {
                    LabeledContent("Managed Agent", value: state.agentId).font(.caption.monospaced()).textSelection(.enabled)
                    Button(state.busy ? "Working…" : "Verify Managed Agent") { Task { state.saveSettings(); await state.createOrRepairAgent() } }.disabled(state.busy)
                    if !state.sessionId.isEmpty {
                        Text("Managed session: \(state.sessionId)").font(.caption2.monospaced()).textSelection(.enabled)
                        Button("Reset Conversation") { state.resetConversation() }
                    }
                }

                Section("Device Control") {
                    Toggle("Allow sensitive actions", isOn: $state.sensitiveActions)
                        .onChange(of: state.sensitiveActions) { v in UserDefaults.standard.set(v, forKey: "nextagent.sensitiveActions") }
                    Toggle("Continue active turns in background", isOn: $state.backgroundContinuation)
                        .onChange(of: state.backgroundContinuation) { v in UserDefaults.standard.set(v, forKey: "nextagent.backgroundContinuation") }
                    Text("Background continuation protects active turns during app switching, retries transient network interruptions, and automatically resumes the durable managed-agent session when Next Agent becomes active again. Multi-app requests use one local sequence so the first launch does not break the remaining actions.")
                        .font(.caption).foregroundStyle(.secondary)
                    Text("When sensitive actions are off, file writes, uicache, respring and process termination are blocked. Root read-only inspection remains available.")
                        .font(.caption).foregroundStyle(.secondary)
                }

                Section("Security") {
                    Text("The test build stores the API key in the iOS Keychain and never commits it into the app. A jailbroken/rooted device can still be compromised by other privileged software; use a dedicated OpenAI project key with a spending limit and rotate it if the phone is lost or untrusted.")
                        .font(.caption)
                    Text("Next Agent intentionally has no tools for reading Keychain credentials, passwords, authentication tokens, microphone, camera, private messages, or arbitrary model-generated shell commands. The v0.3 root daemon also blocks credential/keychain and private communications paths server-side.")
                        .font(.caption)
                }
            }.navigationTitle("Settings")
        }
    }
}
