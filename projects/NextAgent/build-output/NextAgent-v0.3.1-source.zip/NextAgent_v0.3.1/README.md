# Next Agent 0.1.0

Standalone jailbreak/TrollStore iPhone agent. It is intentionally separate from Accountants.

## OpenAI backend
This test build uses the supported OpenAI Responses API with local function tools. Default model: `gpt-5.6-sol`. Conversation continuity is kept with `previous_response_id`.

Create a dedicated OpenAI Platform project and a restricted API key. For this build the key only needs access to create Responses; it does not need Files, Assistants, fine-tuning, or organization administration permissions. Paste the key only into Next Agent Settings. The key is stored in iOS Keychain and is not embedded in the source/TIPA.

## Device tools in 0.1.0
- Device / jailbreak status
- Installed app inventory and app launch
- Open URL / URL scheme
- Clipboard read/write
- List/read user files under `/var/mobile`
- Write user text files when Sensitive Actions is enabled
- Process list
- Network interfaces
- Storage info
- Brightness read/write
- Screenshot attempt via available jailbreak utility
- uicache, respring, terminate PID when Sensitive Actions is enabled

There is deliberately no model-generated arbitrary shell tool and no password/keychain/token dumping.

## Root behavior
The app checks its UID/EUID. Root-only presets use the current EUID first and then try passwordless sudo from common rootless/rootful jailbreak paths. If your bootstrap exposes root through a different helper/daemon, those actions will report that a root helper is required while the rest of the app remains usable.

## Install
Build output is `NextAgent-0.1.0.tipa` for TrollStore. Open Settings, paste the dedicated project API key, keep model `gpt-5.6-sol`, save, tap **Test OpenAI Connection**, then use the Agent tab.
