import SwiftUI
import UIKit
import Foundation
import Security
import Darwin
import MediaPlayer

@main
struct NextAgentApp: App {
    @StateObject private var state = AppState()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(state) }
    }
}

// MARK: - Models

struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let role: String
    let text: String
}

struct ToolResult {
    let success: Bool
    let output: String
}

struct RequiredAction {
    let turnId: String
    let callId: String
    let name: String
    let arguments: [String: Any]
}

// MARK: - App State

@MainActor
final class AppState: ObservableObject {
    @Published var messages: [ChatMessage] = [
        ChatMessage(role: "assistant", text: "Next Agent 0.3.1 is ready with your GPT-6 Astra managed agent and RootHide root helper. Open Settings, save the dedicated OpenAI project API key, verify the agent, then start giving me phone tasks.")
    ]
    @Published var input = ""
    @Published var busy = false
    @Published var status = "Not configured"
    @Published var agentId = "agent_a8bca3810e67406a8076559d2ba2e10f1379810a596e4d3082"
    @Published var sessionId = UserDefaults.standard.string(forKey: "nextagent.managedSessionId") ?? ""
    @Published var model = "gpt-6-astra"
    @Published var sensitiveActions = UserDefaults.standard.bool(forKey: "nextagent.sensitiveActions")
    @Published var apiKeyDraft = CredentialStore.loadAPIKey() ?? ""
    @Published var lastTool = "None"
    @Published var toolLog: [String] = []
    @Published var rootHelperStatus = "Not checked"

    private let tools = DeviceToolRegistry()
    private lazy var client = OpenAIManagedAgentsClient(state: self, tools: tools)

    func saveSettings() {
        let trimmed = apiKeyDraft.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            CredentialStore.deleteAPIKey()
            status = "API key cleared"
        } else {
            let result = CredentialStore.saveAPIKey(trimmed)
            apiKeyDraft = CredentialStore.loadAPIKey() ?? trimmed
            if result.keychainSaved {
                status = "Settings saved securely"
            } else if result.fallbackSaved {
                status = "Settings saved (protected local fallback)"
            } else {
                status = "API key could not be saved (Keychain OSStatus \(result.keychainStatus))"
            }
        }
        UserDefaults.standard.set(sensitiveActions, forKey: "nextagent.sensitiveActions")
        UserDefaults.standard.synchronize()
    }

    func createOrRepairAgent() async {
        saveSettings()
        guard CredentialStore.loadAPIKey() != nil else {
            status = "API key required"
            return
        }
        busy = true
        defer { busy = false }
        do {
            try await client.validateConnection()
            status = "OpenAI connection ready"
        } catch {
            status = "Connection failed: \(error.localizedDescription)"
        }
    }

    func resetConversation() {
        sessionId = ""
        UserDefaults.standard.removeObject(forKey: "nextagent.managedSessionId")
        messages = [ChatMessage(role: "assistant", text: "Managed-agent session reset. Device tools and settings are unchanged.")]
        status = "Conversation reset"
    }

    func send() async {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !busy else { return }
        guard CredentialStore.loadAPIKey() != nil else {
            status = "API key missing"
            return
        }
        input = ""
        messages.append(ChatMessage(role: "user", text: text))
        busy = true
        status = "Agent working…"
        defer { busy = false }
        do {
            let reply = try await client.runUserMessage(text)
            messages.append(ChatMessage(role: "assistant", text: reply))
            status = "Ready"
        } catch {
            messages.append(ChatMessage(role: "assistant", text: "Error: \(error.localizedDescription)"))
            status = "Failed"
        }
    }

    func checkRootHelper() {
        let result = RootDaemonClient.request(action: "ping")
        rootHelperStatus = result.success ? "Connected: \(result.output)" : "Unavailable: \(result.output)"
    }

    func recordTool(_ name: String, _ result: ToolResult) {
        lastTool = name
        let stamp = ISO8601DateFormatter().string(from: Date())
        toolLog.insert("\(stamp)  \(name)  \(result.success ? "OK" : "FAIL")  \(result.output.prefix(180))", at: 0)
        if toolLog.count > 100 { toolLog.removeLast(toolLog.count - 100) }
    }
}

// MARK: - OpenAI Managed Agents API

final class OpenAIManagedAgentsClient {
    weak var state: AppState?
    let tools: DeviceToolRegistry
    private let base = URL(string: "https://api.openai.com/v1/agents/")!
    private let savedAgentId = "agent_a8bca3810e67406a8076559d2ba2e10f1379810a596e4d3082"

    init(state: AppState, tools: DeviceToolRegistry) {
        self.state = state
        self.tools = tools
    }

    private var apiKey: String {
        get throws {
            guard let k = CredentialStore.loadAPIKey(), !k.isEmpty else {
                throw NSError(domain: "NextAgent", code: 401, userInfo: [NSLocalizedDescriptionKey: "OpenAI API key is not configured"])
            }
            return k
        }
    }

    @MainActor
    func validateConnection() async throws {
        guard let state else { throw NSError(domain: "NextAgent", code: 1) }
        let agent = try await requestJSON(method: "GET", path: "/\(savedAgentId)")
        guard (agent["id"] as? String) == savedAgentId else {
            throw apiShape("Saved managed agent was not returned", agent)
        }
        let model = agent["model"] as? String ?? "unknown"
        guard model == "gpt-6-astra" else {
            throw NSError(domain: "NextAgent", code: 409, userInfo: [NSLocalizedDescriptionKey: "Managed agent currently uses \(model), expected gpt-6-astra"])
        }
        state.agentId = savedAgentId
        state.model = model
    }

    @MainActor
    func runUserMessage(_ message: String) async throws -> String {
        guard let state else { throw NSError(domain: "NextAgent", code: 2) }

        let baselineAssistantId: String?
        if state.sessionId.isEmpty {
            baselineAssistantId = nil
            let created = try await createSession(initialMessage: message)
            guard let id = created["id"] as? String, !id.isEmpty else {
                throw apiShape("Managed session response had no session id", created)
            }
            state.sessionId = id
            UserDefaults.standard.set(id, forKey: "nextagent.managedSessionId")
        } else {
            baselineAssistantId = try await latestAssistantMessage(sessionId: state.sessionId)?.id
            try await sendUserMessage(sessionId: state.sessionId, text: message)
        }

        return try await driveSession(sessionId: state.sessionId, baselineAssistantId: baselineAssistantId)
    }

    private func createSession(initialMessage: String) async throws -> [String: Any] {
        let body: [String: Any] = [
            "agent_id": savedAgentId,
            "agent": ["tools": DeviceToolRegistry.toolSchemas],
            "environment": ["type": "none"],
            "input": initialMessage,
            "metadata": ["client": "NextAgent-iPhone", "client_version": "0.3.0"],
            "stream": false
        ]
        return try await requestJSON(method: "POST", path: "/sessions", body: body)
    }

    private func sendUserMessage(sessionId: String, text: String) async throws {
        let body: [String: Any] = [
            "events": [[
                "type": "agent.session.input.message",
                "input": [[
                    "role": "user",
                    "content": [["type": "input_text", "text": text]]
                ]]
            ]]
        ]
        _ = try await requestData(method: "POST", path: "/sessions/\(sessionId)/events", body: body)
    }

    @MainActor
    private func driveSession(sessionId: String, baselineAssistantId: String?) async throws -> String {
        guard let state else { throw NSError(domain: "NextAgent", code: 3) }
        for _ in 0..<240 {
            try Task.checkCancellation()
            let session = try await requestJSON(method: "GET", path: "/sessions/\(sessionId)")
            let status = session["status"] as? String ?? "unknown"

            if status == "failed" {
                let reason = (session["error"] as? String) ?? "Managed agent session failed"
                throw NSError(domain: "NextAgent", code: 500, userInfo: [NSLocalizedDescriptionKey: reason])
            }

            if status == "requires_action" {
                let actions = parseRequiredActions(session)
                guard !actions.isEmpty else {
                    throw apiShape("Session requires action but supplied no supported function calls", session)
                }
                var events: [[String: Any]] = []
                for action in actions {
                    let result = await tools.execute(action.name, arguments: action.arguments, allowSensitive: state.sensitiveActions)
                    state.recordTool(action.name, result)
                    var event: [String: Any] = [
                        "type": "agent.session.input.tool_result",
                        "turn_id": action.turnId,
                        "call_id": action.callId,
                        "success": result.success
                    ]
                    if result.success { event["output"] = result.output }
                    else { event["error"] = result.output }
                    events.append(event)
                }
                _ = try await requestData(method: "POST", path: "/sessions/\(sessionId)/events", body: ["events": events])
                continue
            }

            if status == "idle" {
                if let latest = try await latestAssistantMessage(sessionId: sessionId),
                   latest.id != baselineAssistantId,
                   !latest.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    return latest.text
                }
            }

            try await Task.sleep(nanoseconds: 500_000_000)
        }
        throw NSError(domain: "NextAgent", code: 408, userInfo: [NSLocalizedDescriptionKey: "Managed agent session timed out"])
    }

    private func parseRequiredActions(_ session: [String: Any]) -> [RequiredAction] {
        let raw = session["required_actions"] as? [[String: Any]] ?? []
        return raw.compactMap { item in
            guard (item["type"] as? String) == "function_call",
                  let turnId = item["turn_id"] as? String,
                  let callId = item["call_id"] as? String,
                  let name = item["name"] as? String else { return nil }
            let arguments: [String: Any]
            if let dict = item["arguments"] as? [String: Any] {
                arguments = dict
            } else if let rawString = item["arguments"] as? String,
                      let data = rawString.data(using: .utf8),
                      let obj = try? JSONSerialization.jsonObject(with: data),
                      let dict = obj as? [String: Any] {
                arguments = dict
            } else {
                arguments = [:]
            }
            return RequiredAction(turnId: turnId, callId: callId, name: name, arguments: arguments)
        }
    }

    private func latestAssistantMessage(sessionId: String) async throws -> (id: String, text: String)? {
        let json = try await requestJSON(method: "GET", path: "/sessions/\(sessionId)/items?limit=50&order=desc")
        let items = json["data"] as? [[String: Any]] ?? []
        for item in items {
            guard (item["type"] as? String) == "message",
                  (item["role"] as? String) == "assistant" else { continue }
            let id = item["id"] as? String ?? UUID().uuidString
            let content = item["content"] as? [[String: Any]] ?? []
            let text = content.compactMap { part -> String? in
                guard (part["type"] as? String) == "output_text" else { return nil }
                return part["text"] as? String
            }.joined(separator: "\n")
            if !text.isEmpty { return (id, text) }
        }
        return nil
    }

    private func requestJSON(method: String, path: String, body: [String: Any]? = nil) async throws -> [String: Any] {
        let data = try await requestData(method: method, path: path, body: body)
        guard !data.isEmpty else { return [:] }
        let obj = try JSONSerialization.jsonObject(with: data)
        guard let json = obj as? [String: Any] else {
            throw NSError(domain: "NextAgent", code: 422, userInfo: [NSLocalizedDescriptionKey: "Unexpected OpenAI managed-agent response"])
        }
        return json
    }

    private func requestData(method: String, path: String, body: [String: Any]? = nil) async throws -> Data {
        let key = try apiKey
        let relativePath = path.hasPrefix("/") ? String(path.dropFirst()) : path
        guard let url = URL(string: relativePath, relativeTo: base) else {
            throw NSError(domain: "NextAgent", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid Agents API URL"])
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.timeoutInterval = 120
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("agents=v1", forHTTPHeaderField: "OpenAI-Beta")
        if let body { req.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw NSError(domain: "NextAgent", code: 0) }
        guard (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "NextAgent", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: text])
        }
        return data
    }

    private func apiShape(_ message: String, _ json: [String: Any]) -> NSError {
        NSError(domain: "NextAgent", code: 422, userInfo: [NSLocalizedDescriptionKey: "\(message): \(json)"])
    }
}

// MARK: - Device Tools

final class DeviceToolRegistry {
    static let agentInstructions = """
    You are Next Agent, operating the user's own jailbroken iPhone through explicit local function tools.
    Use tools only when needed and report actual tool results; never claim an action succeeded if a tool did not report success.
    Do not attempt to access passwords, Keychain contents, authentication tokens, financial apps/data, microphone, camera, private messages, or hidden credential stores.
    Do not invent arbitrary shell commands. Use only the provided tools.
    A separately installed nextagentd root helper may provide privileged filesystem/process/system tools. Its protocol is allow-listed and blocks credential stores and private communications data.
    Potentially disruptive tools may be disabled by the user. If a tool reports that sensitive actions are disabled, explain that the user can enable them in Settings and do not try to bypass the control.
    Prefer read-only inspection before changing device state.
    """

    static let toolSchemas: [[String: Any]] = [
        tool("device_info", "Get device, OS, jailbreak/root, root-helper and filesystem status.", [:]),
        tool("root_helper_status", "Check whether the separately installed nextagentd privileged helper is connected and actually running as root.", [:]),
        tool("jailbreak_diagnostics", "Inspect jailbreak/bootstrap paths using the root helper when installed. Read-only.", [:]),
        tool("root_list_files", "List a root-visible directory through nextagentd. Credential stores and private communications roots are blocked by the daemon.", ["path": str("Absolute directory path")], required: ["path"]),
        tool("root_read_text_file", "Read a root-visible UTF-8 text file through nextagentd, up to 256 KB. Credential stores and private communications roots are blocked.", ["path": str("Absolute text file path")], required: ["path"]),
        tool("list_installed_apps", "List installed iOS applications with display name and bundle identifier.", [:]),
        tool("open_url", "Open an http/https or iOS URL scheme on the phone.", ["url": str("URL to open")], required: ["url"]),
        tool("open_app", "Open an installed app by bundle identifier using LaunchServices when available.", ["bundle_id": str("Bundle identifier")], required: ["bundle_id"]),
        tool("clipboard_get", "Read the current general pasteboard text.", [:]),
        tool("clipboard_set", "Replace the general pasteboard text.", ["text": str("Text to put on the clipboard")], required: ["text"]),
        tool("list_files", "List files in an allowed user path. Paths under /var/mobile and the app container are supported when the install has access.", ["path": str("Directory path")], required: ["path"]),
        tool("read_text_file", "Read a UTF-8 text file from an allowed user path. Large files are truncated.", ["path": str("File path")], required: ["path"]),
        tool("write_text_file", "Write UTF-8 text to an allowed user path. Sensitive actions must be enabled.", ["path": str("File path"), "text": str("Text to write")], required: ["path", "text"]),
        tool("process_list", "List running processes using the jailbreak command environment when available.", [:]),
        tool("network_interfaces", "Show local network interface addresses without contacting external services.", [:]),
        tool("device_storage", "Show filesystem capacity and free space.", [:]),
        tool("get_brightness", "Get the current screen brightness from 0 to 1.", [:]),
        tool("set_brightness", "Set the current screen brightness from 0 to 1.", ["value": num("Brightness between 0 and 1")], required: ["value"]),
        tool("take_screenshot", "Attempt a full-device screenshot using available jailbreak screenshot utilities and save it under /var/mobile/Documents/NextAgent.", [:]),
        tool("refresh_icon_cache", "Run uicache to refresh app icons. Sensitive actions must be enabled.", [:]),
        tool("respring", "Respring SpringBoard. This interrupts the UI. Sensitive actions must be enabled.", [:]),
        tool("terminate_process", "Terminate a process by numeric PID. Sensitive actions must be enabled.", ["pid": int("Process ID")], required: ["pid"])
    ]

    private static func tool(_ name: String, _ description: String, _ props: [String: Any], required: [String] = []) -> [String: Any] {
        [
            "type": "function",
            "name": name,
            "description": description,
            "parameters": [
                "type": "object",
                "properties": props,
                "required": required,
                "additionalProperties": false
            ]
        ]
    }
    private static func str(_ d: String) -> [String: Any] { ["type": "string", "description": d] }
    private static func num(_ d: String) -> [String: Any] { ["type": "number", "description": d] }
    private static func int(_ d: String) -> [String: Any] { ["type": "integer", "description": d] }

    @MainActor
    func execute(_ name: String, arguments: [String: Any], allowSensitive: Bool) async -> ToolResult {
        switch name {
        case "device_info": return deviceInfo()
        case "root_helper_status": return RootDaemonClient.request(action: "ping")
        case "jailbreak_diagnostics": return RootDaemonClient.request(action: "jailbreak_info")
        case "root_list_files":
            guard let path = arguments["path"] as? String else { return badArgs() }
            return RootDaemonClient.request(action: "list", argument: path)
        case "root_read_text_file":
            guard let path = arguments["path"] as? String else { return badArgs() }
            return RootDaemonClient.request(action: "read", argument: path)
        case "list_installed_apps": return listApps()
        case "open_url": return openURL(arguments)
        case "open_app": return openApp(arguments)
        case "clipboard_get": return ToolResult(success: true, output: UIPasteboard.general.string ?? "")
        case "clipboard_set":
            guard let text = arguments["text"] as? String else { return badArgs() }
            UIPasteboard.general.string = text
            return ToolResult(success: true, output: "Clipboard updated")
        case "list_files": return listFiles(arguments)
        case "read_text_file": return readText(arguments)
        case "write_text_file":
            guard allowSensitive else { return sensitiveOff() }
            return writeText(arguments)
        case "process_list":
            let privileged = RootDaemonClient.request(action: "ps")
            return privileged.success ? privileged : ShellRunner.runPreset("ps -axo pid,user,comm | head -n 250")
        case "network_interfaces": return ShellRunner.runPreset("ifconfig 2>/dev/null || ip addr 2>/dev/null")
        case "device_storage": return ShellRunner.runPreset("df -h / /var /var/mobile 2>/dev/null | uniq")
        case "get_brightness": return ToolResult(success: true, output: String(format: "%.3f", UIScreen.main.brightness))
        case "set_brightness":
            guard let v = arguments["value"] as? NSNumber else { return badArgs() }
            UIScreen.main.brightness = CGFloat(max(0, min(1, v.doubleValue)))
            return ToolResult(success: true, output: "Brightness set to \(UIScreen.main.brightness)")
        case "take_screenshot": return screenshot()
        case "refresh_icon_cache":
            guard allowSensitive else { return sensitiveOff() }
            let daemon = RootDaemonClient.request(action: "uicache")
            return daemon.success ? daemon : ShellRunner.runRootPreset("uicache -a 2>&1")
        case "respring":
            guard allowSensitive else { return sensitiveOff() }
            let daemon = RootDaemonClient.request(action: "respring")
            return daemon.success ? daemon : ShellRunner.runRootPreset("(command -v sbreload >/dev/null && sbreload) || killall SpringBoard")
        case "terminate_process":
            guard allowSensitive else { return sensitiveOff() }
            guard let pid = (arguments["pid"] as? NSNumber)?.intValue, pid > 20 else { return badArgs() }
            let daemon = RootDaemonClient.request(action: "kill", argument: String(pid))
            return daemon.success ? daemon : ShellRunner.runRootPreset("kill -TERM \(pid)")
        default: return ToolResult(success: false, output: "Unknown tool: \(name)")
        }
    }

    private func deviceInfo() -> ToolResult {
        var uts = utsname(); uname(&uts)
        let machineCapacity = MemoryLayout.size(ofValue: uts.machine)
        let machine = withUnsafePointer(to: &uts.machine) { p in
            p.withMemoryRebound(to: CChar.self, capacity: machineCapacity) { String(cString: $0) }
        }
        let roots = ["/var/jb", "/Applications", "/private/preboot"]
        let present = roots.filter { FileManager.default.fileExists(atPath: $0) }
        var info: [String: Any] = [
            "name": UIDevice.current.name,
            "model": UIDevice.current.model,
            "machine": machine,
            "system": UIDevice.current.systemName,
            "version": UIDevice.current.systemVersion,
            "uid": getuid(),
            "euid": geteuid(),
            "jailbreak_paths": present,
            "bundle": Bundle.main.bundleIdentifier ?? ""
        ]
        let daemon = RootDaemonClient.request(action: "ping")
        if daemon.success,
           let data = daemon.output.data(using: .utf8),
           let obj = try? JSONSerialization.jsonObject(with: data) {
            info["root_helper"] = obj
        } else {
            info["root_helper"] = ["connected": false, "detail": daemon.output]
        }
        return jsonResult(info)
    }

    private func listApps() -> ToolResult {
        guard let cls = NSClassFromString("LSApplicationWorkspace") else {
            return ToolResult(success: false, output: "LaunchServices is unavailable on this install")
        }
        let classObject: AnyObject = cls as AnyObject
        guard let unmanaged = classObject.perform(NSSelectorFromString("defaultWorkspace")),
              let ws = unmanaged.takeUnretainedValue() as? NSObject,
              let appsValue = ws.perform(NSSelectorFromString("allInstalledApplications"))?.takeUnretainedValue(),
              let apps = appsValue as? [NSObject] else {
            return ToolResult(success: false, output: "LaunchServices app enumeration is unavailable on this install")
        }
        var rows: [[String: String]] = []
        for app in apps.prefix(500) {
            let bid = app.value(forKey: "applicationIdentifier") as? String ?? ""
            let name = app.value(forKey: "localizedName") as? String ?? app.value(forKey: "itemName") as? String ?? bid
            if !bid.isEmpty { rows.append(["name": name, "bundle_id": bid]) }
        }
        rows.sort { ($0["name"] ?? "") < ($1["name"] ?? "") }
        return jsonResult(["count": rows.count, "apps": rows])
    }

    private func openApp(_ args: [String: Any]) -> ToolResult {
        guard let bid = args["bundle_id"] as? String, !bid.isEmpty else { return badArgs() }
        guard let cls = NSClassFromString("LSApplicationWorkspace") else {
            return ToolResult(success: false, output: "LaunchServices unavailable")
        }
        let classObject: AnyObject = cls as AnyObject
        guard let unmanaged = classObject.perform(NSSelectorFromString("defaultWorkspace")),
              let ws = unmanaged.takeUnretainedValue() as? NSObject else {
            return ToolResult(success: false, output: "LaunchServices unavailable")
        }
        let sel = NSSelectorFromString("openApplicationWithBundleID:")
        guard ws.responds(to: sel) else { return ToolResult(success: false, output: "App launch selector unavailable") }
        _ = ws.perform(sel, with: bid)
        return ToolResult(success: true, output: "Launch request sent for \(bid)")
    }

    private func openURL(_ args: [String: Any]) -> ToolResult {
        guard let s = args["url"] as? String, let url = URL(string: s) else { return badArgs() }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        return ToolResult(success: true, output: "Open request sent for \(s)")
    }

    private func allowedPath(_ raw: String) -> String? {
        let p = (raw as NSString).standardizingPath
        let home = NSHomeDirectory()
        if p == "/var/mobile" || p.hasPrefix("/var/mobile/") || p == home || p.hasPrefix(home + "/") { return p }
        return nil
    }

    private func listFiles(_ args: [String: Any]) -> ToolResult {
        guard let raw = args["path"] as? String, let p = allowedPath(raw) else { return ToolResult(success: false, output: "Path is outside allowed user roots") }
        do {
            let rows = try FileManager.default.contentsOfDirectory(atPath: p).prefix(500).map { name -> [String: Any] in
                let full = (p as NSString).appendingPathComponent(name)
                let attrs = try? FileManager.default.attributesOfItem(atPath: full)
                return ["name": name, "directory": (attrs?[.type] as? FileAttributeType) == .typeDirectory, "size": attrs?[.size] as? NSNumber ?? 0]
            }
            return jsonResult(["path": p, "items": Array(rows)])
        } catch { return ToolResult(success: false, output: error.localizedDescription) }
    }

    private func readText(_ args: [String: Any]) -> ToolResult {
        guard let raw = args["path"] as? String, let p = allowedPath(raw) else { return ToolResult(success: false, output: "Path is outside allowed user roots") }
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: p), options: [.mappedIfSafe])
            let clipped = data.prefix(250_000)
            guard let text = String(data: clipped, encoding: .utf8) else { return ToolResult(success: false, output: "File is not UTF-8 text") }
            return ToolResult(success: true, output: text + (data.count > clipped.count ? "\n[truncated]" : ""))
        } catch { return ToolResult(success: false, output: error.localizedDescription) }
    }

    private func writeText(_ args: [String: Any]) -> ToolResult {
        guard let raw = args["path"] as? String, let p = allowedPath(raw), let text = args["text"] as? String else { return badArgs() }
        do {
            try FileManager.default.createDirectory(at: URL(fileURLWithPath: (p as NSString).deletingLastPathComponent), withIntermediateDirectories: true)
            try text.write(toFile: p, atomically: true, encoding: .utf8)
            return ToolResult(success: true, output: "Wrote \(text.utf8.count) bytes to \(p)")
        } catch { return ToolResult(success: false, output: error.localizedDescription) }
    }

    private func screenshot() -> ToolResult {
        let dir = "/var/mobile/Documents/NextAgent"
        try? FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true)
        let file = "\(dir)/screenshot-\(Int(Date().timeIntervalSince1970)).png"
        let candidates = [
            "screencapture -x '\(file)'",
            "/usr/bin/screencapture -x '\(file)'",
            "/var/jb/usr/bin/screencapture -x '\(file)'"
        ]
        for command in candidates {
            let result = ShellRunner.runRootPreset(command)
            if result.success && FileManager.default.fileExists(atPath: file) {
                return ToolResult(success: true, output: file)
            }
        }
        return ToolResult(success: false, output: "No compatible full-device screenshot utility was found")
    }

    private func jsonResult(_ obj: Any) -> ToolResult {
        guard JSONSerialization.isValidJSONObject(obj), let data = try? JSONSerialization.data(withJSONObject: obj, options: [.prettyPrinted]), let text = String(data: data, encoding: .utf8) else {
            return ToolResult(success: false, output: "Could not serialize result")
        }
        return ToolResult(success: true, output: text)
    }
    private func badArgs() -> ToolResult { ToolResult(success: false, output: "Invalid or missing arguments") }
    private func sensitiveOff() -> ToolResult { ToolResult(success: false, output: "Sensitive actions are disabled in Next Agent Settings") }
}


// MARK: - Privileged helper client

enum RootDaemonClient {
    private static let host = "127.0.0.1"
    private static let port: UInt16 = 37589
    private static let tokenPaths = [
        "/var/mobile/Library/NextAgent/daemon.token",
        "/private/var/mobile/Library/NextAgent/daemon.token"
    ]

    static func request(action: String, argument: String = "") -> ToolResult {
        guard action.range(of: "^[a-z_]+$", options: .regularExpression) != nil else {
            return ToolResult(success: false, output: "Invalid daemon action")
        }
        let tokenLoad = loadToken()
        guard let rawToken = tokenLoad.token else {
            return ToolResult(success: false, output: "Root helper token is unavailable. " + tokenLoad.detail)
        }
        let token = rawToken.trimmingCharacters(in: .whitespacesAndNewlines)
        guard token.count == 64 else { return ToolResult(success: false, output: "Root helper token is invalid") }

        let fd = Darwin.socket(AF_INET, SOCK_STREAM, 0)
        guard fd >= 0 else { return ToolResult(success: false, output: "socket failed: \(String(cString: strerror(errno)))") }
        defer { Darwin.close(fd) }

        var tv = timeval(tv_sec: 3, tv_usec: 0)
        _ = withUnsafePointer(to: &tv) { p in
            Darwin.setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, p, socklen_t(MemoryLayout<timeval>.size))
        }
        _ = withUnsafePointer(to: &tv) { p in
            Darwin.setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, p, socklen_t(MemoryLayout<timeval>.size))
        }

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = in_port_t(port.bigEndian)
        let ipResult = host.withCString { inet_pton(AF_INET, $0, &addr.sin_addr) }
        guard ipResult == 1 else { return ToolResult(success: false, output: "inet_pton failed") }
        let connected = withUnsafePointer(to: &addr) { p in
            p.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                Darwin.connect(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard connected == 0 else {
            return ToolResult(success: false, output: "Root helper is not listening on 127.0.0.1:\(port): \(String(cString: strerror(errno)))")
        }

        let encoded = Data(argument.utf8).base64EncodedString()
        let line = "NAGENT1 \(token) \(action) \(encoded.isEmpty ? "-" : encoded)\n"
        guard writeAll(fd: fd, data: Data(line.utf8)) else {
            return ToolResult(success: false, output: "Failed to send request to root helper")
        }
        guard let header = readLine(fd: fd, max: 128) else {
            return ToolResult(success: false, output: "Root helper did not return a response header")
        }
        let parts = header.split(separator: " ", maxSplits: 1).map(String.init)
        guard parts.count == 2, let count = Int(parts[1]), count >= 0, count <= 524_288 else {
            return ToolResult(success: false, output: "Malformed root helper response")
        }
        guard let data = readExact(fd: fd, count: count) else {
            return ToolResult(success: false, output: "Incomplete root helper response")
        }
        let output = String(data: data, encoding: .utf8) ?? "[non-UTF8 daemon output]"
        return ToolResult(success: parts[0] == "OK", output: output)
    }

    private static func loadToken() -> (token: String?, detail: String) {
        var diagnostics: [String] = []
        for path in tokenPaths {
            errno = 0
            let fd = Darwin.open(path, O_RDONLY)
            if fd < 0 {
                diagnostics.append("\(path): open failed errno=\(errno) (\(String(cString: strerror(errno))))")
                continue
            }

            var buffer = [UInt8](repeating: 0, count: 128)
            errno = 0
            let n = Darwin.read(fd, &buffer, buffer.count - 1)
            let readErrno = errno
            Darwin.close(fd)

            if n <= 0 {
                diagnostics.append("\(path): read failed errno=\(readErrno) (\(String(cString: strerror(readErrno))))")
                continue
            }
            let data = Data(buffer.prefix(Int(n)))
            guard let text = String(data: data, encoding: .utf8) else {
                diagnostics.append("\(path): token was not UTF-8")
                continue
            }
            let token = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if token.count == 64 {
                return (token, "read from \(path)")
            }
            diagnostics.append("\(path): unexpected token length \(token.count)")
        }
        return (nil, diagnostics.joined(separator: " | "))
    }

    private static func writeAll(fd: Int32, data: Data) -> Bool {
        var sent = 0
        return data.withUnsafeBytes { raw in
            guard let base = raw.baseAddress else { return false }
            while sent < data.count {
                let n = Darwin.write(fd, base.advanced(by: sent), data.count - sent)
                if n <= 0 { return false }
                sent += n
            }
            return true
        }
    }

    private static func readLine(fd: Int32, max: Int) -> String? {
        var bytes: [UInt8] = []
        bytes.reserveCapacity(min(max, 128))
        while bytes.count < max {
            var byte: UInt8 = 0
            let n = Darwin.read(fd, &byte, 1)
            if n <= 0 { return nil }
            if byte == 10 { break }
            bytes.append(byte)
        }
        return String(bytes: bytes, encoding: .utf8)
    }

    private static func readExact(fd: Int32, count: Int) -> Data? {
        if count == 0 { return Data() }
        var data = Data(count: count)
        var readCount = 0
        let ok = data.withUnsafeMutableBytes { raw -> Bool in
            guard let base = raw.baseAddress else { return false }
            while readCount < count {
                let n = Darwin.read(fd, base.advanced(by: readCount), count - readCount)
                if n <= 0 { return false }
                readCount += n
            }
            return true
        }
        return ok ? data : nil
    }
}

// MARK: - Shell

enum ShellRunner {
    static func runPreset(_ command: String) -> ToolResult { run(shell: bestShell(), command: command) }

    static func runRootPreset(_ command: String) -> ToolResult {
        if geteuid() == 0 { return run(shell: bestShell(), command: command) }
        let sudoCandidates = ["/var/jb/usr/bin/sudo", "/usr/bin/sudo", "/bin/sudo"]
        for sudo in sudoCandidates where FileManager.default.isExecutableFile(atPath: sudo) {
            let result = spawn(sudo, [sudo, "-n", bestShell(), "-c", command])
            if result.0 == 0 { return ToolResult(success: true, output: result.1) }
        }
        let plain = run(shell: bestShell(), command: command)
        if plain.success { return plain }
        return ToolResult(success: false, output: "Root command failed. UID=\(geteuid()). Configure passwordless sudo/root helper for the jailbreak if root-only actions are required. \(plain.output)")
    }

    private static func bestShell() -> String {
        ["/var/jb/bin/sh", "/bin/sh"].first(where: { FileManager.default.isExecutableFile(atPath: $0) }) ?? "/bin/sh"
    }

    private static func run(shell: String, command: String) -> ToolResult {
        let (code, output) = spawn(shell, [shell, "-c", command])
        return ToolResult(success: code == 0, output: output.isEmpty ? "exit=\(code)" : output)
    }

    private static func spawn(_ path: String, _ argvStrings: [String]) -> (Int32, String) {
        var pipefd: [Int32] = [0, 0]
        guard pipe(&pipefd) == 0 else { return (errno, "pipe failed") }
        defer { close(pipefd[0]) }

        var actions: posix_spawn_file_actions_t? = nil
        posix_spawn_file_actions_init(&actions)
        posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, pipefd[0])

        var argv = argvStrings.map { strdup($0) }
        argv.append(nil)
        defer { argv.forEach { if let p = $0 { free(p) } } }

        var pid: pid_t = 0
        let rc: Int32 = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, path, &actions, nil, buffer.baseAddress, environ)
        }
        posix_spawn_file_actions_destroy(&actions)
        close(pipefd[1])
        if rc != 0 { return (rc, String(cString: strerror(rc))) }

        var data = Data()
        var buffer = [UInt8](repeating: 0, count: 4096)
        while true {
            let n = read(pipefd[0], &buffer, buffer.count)
            if n <= 0 { break }
            data.append(contentsOf: buffer.prefix(Int(n)))
            if data.count > 500_000 { break }
        }
        var status: Int32 = 0
        waitpid(pid, &status, 0)
        let exitCode: Int32 = (status & 0x7f) == 0 ? ((status >> 8) & 0xff) : -1
        let output = String(data: data, encoding: .utf8) ?? ""
        return (exitCode, output)
    }
}

// MARK: - Credential persistence

struct CredentialSaveResult {
    let keychainSaved: Bool
    let keychainStatus: OSStatus
    let fallbackSaved: Bool
}

enum KeychainStore {
    private static let service = "uk.zeshanbarvi.nextagent.credentials"

    @discardableResult
    static func save(_ value: String, key: String) -> OSStatus {
        let data = Data(value.utf8)
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: key
        ]
        let attributes: [CFString: Any] = [
            kSecValueData: data,
            kSecAttrAccessible: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let updateStatus = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if updateStatus == errSecSuccess { return updateStatus }
        if updateStatus != errSecItemNotFound { return updateStatus }

        var add = query
        add[kSecValueData] = data
        add[kSecAttrAccessible] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(add as CFDictionary, nil)
    }

    static func load(_ key: String) -> (String?, OSStatus) {
        var item: CFTypeRef?
        let status = SecItemCopyMatching([
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: key,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ] as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else { return (nil, status) }
        return (String(data: data, encoding: .utf8), status)
    }

    @discardableResult
    static func delete(_ key: String) -> OSStatus {
        SecItemDelete([
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: key
        ] as CFDictionary)
    }
}

enum CredentialStore {
    private static let account = "openai_api_key"

    private static var fallbackURL: URL? {
        do {
            let root = try FileManager.default.url(for: .applicationSupportDirectory,
                                                   in: .userDomainMask,
                                                   appropriateFor: nil,
                                                   create: true)
            let dir = root.appendingPathComponent("NextAgent", isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true,
                                                    attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
            return dir.appendingPathComponent("openai-project-key.bin")
        } catch {
            return nil
        }
    }

    static func saveAPIKey(_ value: String) -> CredentialSaveResult {
        let keychainStatus = KeychainStore.save(value, key: account)
        let keychainSaved = keychainStatus == errSecSuccess
        var fallbackSaved = false
        if let url = fallbackURL, let data = value.data(using: .utf8) {
            do {
                try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
                fallbackSaved = true
            } catch {
                fallbackSaved = false
            }
        }
        return CredentialSaveResult(keychainSaved: keychainSaved,
                                    keychainStatus: keychainStatus,
                                    fallbackSaved: fallbackSaved)
    }

    static func loadAPIKey() -> String? {
        let (keychainValue, _) = KeychainStore.load(account)
        if let keychainValue, !keychainValue.isEmpty { return keychainValue }
        guard let url = fallbackURL,
              let data = try? Data(contentsOf: url),
              let value = String(data: data, encoding: .utf8),
              !value.isEmpty else { return nil }
        return value
    }

    static func deleteAPIKey() {
        _ = KeychainStore.delete(account)
        if let url = fallbackURL { try? FileManager.default.removeItem(at: url) }
    }
}

// MARK: - UI

struct RootView: View {
    @EnvironmentObject var state: AppState
    var body: some View {
        TabView {
            ChatView().tabItem { Label("Agent", systemImage: "sparkles") }
            ToolsView().tabItem { Label("Tools", systemImage: "wrench.and.screwdriver") }
            SettingsView().tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .tint(.primary)
    }
}

struct ChatView: View {
    @EnvironmentObject var state: AppState
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    Circle().frame(width: 8, height: 8).opacity(state.busy ? 0.45 : 1)
                    Text(state.status).font(.caption).lineLimit(1)
                    Spacer()
                    if !state.lastTool.isEmpty { Text("Tool: \(state.lastTool)").font(.caption2).foregroundStyle(.secondary) }
                }.padding(.horizontal).padding(.vertical, 8)

                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 10) {
                            ForEach(state.messages) { m in
                                HStack {
                                    if m.role == "assistant" {
                                        Text(m.text).padding(10).background(.thinMaterial).clipShape(RoundedRectangle(cornerRadius: 12))
                                        Spacer(minLength: 35)
                                    } else {
                                        Spacer(minLength: 35)
                                        Text(m.text).padding(10).foregroundStyle(.white).background(.black).clipShape(RoundedRectangle(cornerRadius: 12))
                                    }
                                }.id(m.id)
                            }
                        }.padding()
                    }
                    .onChange(of: state.messages.count) { _ in if let id = state.messages.last?.id { proxy.scrollTo(id, anchor: .bottom) } }
                }

                Divider()
                HStack(alignment: .bottom) {
                    TextField("Ask Next Agent to inspect or control this iPhone…", text: $state.input, axis: .vertical)
                        .textFieldStyle(.roundedBorder).lineLimit(1...5)
                    Button {
                        Task { await state.send() }
                    } label: {
                        if state.busy { ProgressView().frame(width: 32, height: 32) }
                        else { Image(systemName: "arrow.up.circle.fill").font(.system(size: 30)) }
                    }.disabled(state.busy || state.input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }.padding()
            }
            .navigationTitle("Next Agent")
        }
    }
}

struct ToolsView: View {
    @EnvironmentObject var state: AppState
    var body: some View {
        NavigationStack {
            List {
                Section("Runtime") {
                    LabeledContent("UID", value: "\(getuid())")
                    LabeledContent("EUID", value: "\(geteuid())")
                    LabeledContent("Root helper", value: state.rootHelperStatus)
                    Button("Test Root Helper") { state.checkRootHelper() }
                    LabeledContent("Sensitive actions", value: state.sensitiveActions ? "Enabled" : "Disabled")
                    LabeledContent("Last tool", value: state.lastTool)
                }
                Section("Available to the agent") {
                    ForEach(["Device info", "Root helper status", "Root jailbreak diagnostics", "Root file listing / text reads", "Installed apps", "Open app / URL", "Clipboard", "User files", "Processes", "Network interfaces", "Storage", "Brightness", "Screenshot attempt", "uicache*", "Respring*", "Terminate process*"], id: \.self) { Text($0) }
                    Text("* requires Sensitive actions in Settings").font(.caption).foregroundStyle(.secondary)
                }
                Section("Tool log") {
                    if state.toolLog.isEmpty { Text("No tool calls yet").foregroundStyle(.secondary) }
                    ForEach(state.toolLog, id: \.self) { Text($0).font(.caption.monospaced()).textSelection(.enabled) }
                }
            }.navigationTitle("Device Tools")
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var state: AppState
    @State private var revealKey = false
    var body: some View {
        NavigationStack {
            Form {
                Section("OpenAI") {
                    if revealKey {
                        TextField("API key", text: $state.apiKeyDraft).textInputAutocapitalization(.never).autocorrectionDisabled()
                    } else {
                        SecureField("API key", text: $state.apiKeyDraft).textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Toggle("Show key", isOn: $revealKey)
                    LabeledContent("Model", value: state.model)
                    Text("Model and reasoning are controlled by the saved managed-agent definition.").font(.caption).foregroundStyle(.secondary)
                    Button("Save Settings") { state.saveSettings() }
                }

                Section("OpenAI Connection") {
                    LabeledContent("Managed Agent", value: state.agentId).font(.caption.monospaced()).textSelection(.enabled)
                    Button(state.busy ? "Working…" : "Verify Managed Agent") { Task { state.saveSettings(); await state.createOrRepairAgent() } }.disabled(state.busy)
                    if !state.sessionId.isEmpty {
                        Text("Managed session: \(state.sessionId)").font(.caption2.monospaced()).textSelection(.enabled)
                        Button("Reset Conversation") { state.resetConversation() }
                    }
                }

                Section("Device Control") {
                    Toggle("Allow sensitive actions", isOn: $state.sensitiveActions)
                        .onChange(of: state.sensitiveActions) { v in UserDefaults.standard.set(v, forKey: "nextagent.sensitiveActions") }
                    Text("When off, file writes, uicache, respring and process termination are blocked even if the agent requests them. Root read-only inspection remains available when nextagentd is installed.")
                        .font(.caption).foregroundStyle(.secondary)
                }

                Section("Security") {
                    Text("The test build stores the API key in the iOS Keychain and never commits it into the app. A jailbroken/rooted device can still be compromised by other privileged software; use a dedicated OpenAI project key with a spending limit and rotate it if the phone is lost or untrusted.")
                        .font(.caption)
                    Text("Next Agent intentionally has no tools for reading Keychain credentials, passwords, authentication tokens, microphone, camera, private messages, or arbitrary model-generated shell commands. The v0.3 root daemon also blocks credential/keychain and private communications paths server-side.")
                        .font(.caption)
                }
            }.navigationTitle("Settings")
        }
    }
}
