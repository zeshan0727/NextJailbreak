"""Opt-in OpenAI document classifier. Default is completely local/offline.
Only truncated extracted text is transmitted; never sends an entire file.
"""
from __future__ import annotations

import base64
import ctypes
import json
import os
from ctypes import wintypes
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from .core import CATEGORIES


class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob(data: bytes):
    arr = ctypes.create_string_buffer(data)
    return _BLOB(len(data), ctypes.cast(arr, ctypes.POINTER(ctypes.c_byte))), arr


def windows_protect(secret: str) -> bytes:
    if os.name != "nt":
        raise OSError("Persistent API keys are supported only on Windows")
    crypt = ctypes.windll.crypt32
    kernel = ctypes.windll.kernel32
    src, buf = _blob(secret.encode("utf-8"))
    dest = _BLOB()
    if not crypt.CryptProtectData(ctypes.byref(src), "File Manager", None, None, None, 0, ctypes.byref(dest)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(dest.pbData, dest.cbData)
    finally:
        kernel.LocalFree(ctypes.cast(dest.pbData, ctypes.c_void_p))


def windows_unprotect(value: bytes) -> str:
    if os.name != "nt":
        return ""
    crypt = ctypes.windll.crypt32
    kernel = ctypes.windll.kernel32
    src, buf = _blob(value)
    dest = _BLOB()
    if not crypt.CryptUnprotectData(ctypes.byref(src), None, None, None, None, 0, ctypes.byref(dest)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(dest.pbData, dest.cbData).decode("utf-8")
    finally:
        kernel.LocalFree(ctypes.cast(dest.pbData, ctypes.c_void_p))


class SettingsStore:
    def __init__(self):
        if os.name == "nt":
            base = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "NextFileManager"
            default_root = Path.home() / "Documents" / "File Manager Library"
        else:
            base = Path.home() / ".nextfilemanager"
            default_root = Path.home() / "Documents" / "File Manager Library"
        base.mkdir(parents=True, exist_ok=True)
        self.path = base / "settings.json"
        self.key_path = base / "api_key.bin"
        self.defaults = {
            "library_root": str(default_root),
            "ai_enabled": False,
            "ai_model": "gpt-4o-mini",
            "move_original": False,
            "auto_file": True,
            "seed_companies": True,
        }
        self.data = dict(self.defaults)
        if self.path.exists():
            try:
                self.data.update({k: v for k, v in json.loads(self.path.read_text(encoding="utf-8")).items() if k in self.defaults})
            except Exception:
                pass

    def save(self):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)

    def set_key(self, value: str):
        value = value.strip()
        if not value:
            self.key_path.unlink(missing_ok=True)
            return
        self.key_path.write_bytes(windows_protect(value))

    def get_key(self) -> str:
        if os.environ.get("OPENAI_API_KEY"):
            return os.environ["OPENAI_API_KEY"]
        if self.key_path.exists():
            try:
                return windows_unprotect(self.key_path.read_bytes())
            except Exception:
                return ""
        return ""


class CloudAI:
    def __init__(self, settings: SettingsStore):
        self.settings = settings

    def available(self) -> bool:
        return bool(self.settings.data.get("ai_enabled") and self.settings.get_key())

    def expand_search(self, query: str, companies: list[dict]) -> dict:
        """Optional AI query expansion; no document content is sent for search."""
        if not self.available():
            raise RuntimeError("Enable cloud AI and enter your API key in Settings to use AI Find.")
        company_names = [{"id": c["id"], "name": c["name"], "aliases": c["aliases"]} for c in companies]
        payload = {
            "model": self.settings.data.get("ai_model") or "gpt-4o-mini",
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": "Transform a user's short or natural-language document search into expanded high-recall search terms. Respond ONLY with JSON containing terms (list of max 9 short keywords or common document reference words), company_id (int from list or null), category (exact listed category or null), year (4 digit string or null). Preserve exact reference numbers. Do not fabricate document contents. Use only provided company IDs."},
                {"role": "user", "content": json.dumps({"query": query[:500], "companies": company_names, "categories": list(CATEGORIES)}, ensure_ascii=False)},
            ],
        }
        req = Request("https://api.openai.com/v1/chat/completions", data=json.dumps(payload).encode(),
                      headers={"Authorization": "Bearer " + self.settings.get_key(), "Content-Type": "application/json"}, method="POST")
        try:
            with urlopen(req, timeout=35) as result:
                data = json.loads(result.read().decode())
            output = json.loads(data["choices"][0]["message"]["content"])
            valid_ids = {c["id"] for c in companies}
            cid = output.get("company_id")
            output["company_id"] = int(cid) if cid is not None and int(cid) in valid_ids else None
            output["terms"] = [str(s)[:45] for s in output.get("terms", []) if isinstance(s, str)][:9]
            output["category"] = output.get("category") if output.get("category") in CATEGORIES else None
            year = str(output.get("year") or "")
            output["year"] = year if len(year) == 4 and year.isdigit() else None
            return output
        except HTTPError as exc:
            raise RuntimeError(f"OpenAI returned HTTP {exc.code}") from exc

    def classify(self, path, analysis, companies):
        """No binary/pdf/image leaves the device; AI receives only 10,000 chars of extracted text."""
        if not self.available():
            return None
        # No content to send means cloud can't reliably improve classification.
        if not analysis.extracted_text.strip():
            return None
        key = self.settings.get_key()
        options = [{"id": c["id"], "name": c["name"], "aliases": c["aliases"]} for c in companies]
        context = {
            "filename": path.name,
            "document_excerpt": analysis.extracted_text[:10000],
            "companies": options,
            "categories": list(CATEGORIES),
            "local_suggestion": {"company": analysis.company_name, "category": analysis.category},
        }
        payload = {
            "model": self.settings.data.get("ai_model") or "gpt-4o-mini",
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": "Classify corporate documents strictly against the provided company IDs and categories. Respond with a JSON object with fields company_id (integer or null), category (exact allowed string), confidence (number 0 to 1), reason (brief string). Never invent a company; lower confidence when more than one company appears."},
                {"role": "user", "content": json.dumps(context, ensure_ascii=False)},
            ],
        }
        req = Request(
            "https://api.openai.com/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(req, timeout=35) as res:
                obj = json.loads(res.read().decode())
            reply = obj["choices"][0]["message"]["content"]
            result = json.loads(reply)
            if result.get("company_id") is not None:
                result["company_id"] = int(result["company_id"])
            return result
        except HTTPError as exc:
            raise RuntimeError(f"OpenAI returned HTTP {exc.code}") from exc
