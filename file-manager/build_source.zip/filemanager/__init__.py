"""Next File Manager desktop application."""
