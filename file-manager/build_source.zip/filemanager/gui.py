"""A Windows-first, light, keyboard-friendly document library UI."""
from __future__ import annotations

import os
import queue
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    AppRoot = TkinterDnD.Tk
    DND_ENABLED = True
except ImportError:
    AppRoot = tk.Tk
    DND_ENABLED = False

from .ai import CloudAI, SettingsStore
from .core import CATEGORIES, FileManagerCore

# Calm, high-contrast light desktop theme. All panels and dialogs share one palette.
C = {
    "bg": "#F5F8FC", "side": "#FFFFFF", "panel": "#FFFFFF", "surface": "#F2F6FB",
    "surface2": "#EAF2FF", "edge": "#D7E2EF", "text": "#172A41",
    "sub": "#526980", "muted": "#71859A", "aqua": "#2563EB", "blue": "#127E83",
    "amber": "#A36B00", "red": "#B42318", "white": "#FFFFFF",
}

FONT = "Segoe UI"


def text(parent, value, size=10, color="text", weight="normal", bg="bg", **kw):
    return tk.Label(parent, text=value, font=(FONT, size, weight), bg=C.get(bg, bg), fg=C.get(color, color), **kw)


def btn(parent, value, command, accent=False, small=False, danger=False, **kw):
    bg = C["aqua"] if accent else (C["surface2"] if not danger else "#422832")
    fg = C["bg"] if accent else (C["red"] if danger else C["text"])
    widget = tk.Button(parent, text=value, command=command, font=(FONT, 9 if small else 10, "bold"),
                       bg=bg, fg=fg, activebackground=C["blue"] if accent else C["edge"],
                       activeforeground=C["white"] if accent else C["text"], bd=0,
                       relief="flat", cursor="hand2", padx=12 if small else 17,
                       pady=7 if small else 10, **kw)
    return widget


class FileManagerApp(AppRoot):
    def __init__(self):
        super().__init__()
        self.title("File Manager  •  Smart Company Library")
        # Fit the opening window to the user's real Windows display, including laptops.
        screen_w, screen_h = self.winfo_screenwidth(), self.winfo_screenheight()
        w = min(1420, max(920, screen_w - 95))
        h = min(850, max(630, screen_h - 110))
        self.geometry(f"{w}x{h}+{max(0, (screen_w-w)//2)}+{max(0, (screen_h-h)//2)}")
        self.minsize(940, 620)
        self.configure(bg=C["bg"])
        self.settings = SettingsStore()
        self.core = FileManagerCore(Path(self.settings.data["library_root"]),
                                    seed_companies=self.settings.data["seed_companies"])
        self.ai = CloudAI(self.settings)
        self.active_company = None
        self.current_view = "all"
        self.search_rows = []
        self.selected_id = None
        self.busy = False
        self.messages = queue.Queue()
        self.search_after = None
        self.ai_search_payload = None
        self._styles()
        self._layout()
        self._refresh()
        self.bind("<Control-f>", lambda _: self.focus_search())
        self.bind("<Control-k>", lambda _: self.focus_search())
        self.bind("<Control-o>", lambda _: self.pick_files())
        self.bind("<Control-n>", lambda _: self.add_company())
        self.bind("<F5>", lambda _: self._refresh())
        self.protocol("WM_DELETE_WINDOW", self.close_app)
        self.after(120, self._poll)

    def _styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Library.Treeview", background=C["panel"], fieldbackground=C["panel"],
                        foreground=C["text"], rowheight=37, borderwidth=0,
                        font=(FONT, 10))
        style.configure("Library.Treeview.Heading", background=C["surface"], foreground=C["sub"],
                        relief="flat", font=(FONT, 9, "bold"), padding=12)
        style.map("Library.Treeview", background=[("selected", C["surface2"])],
                  foreground=[("selected", C["aqua"])])
        style.map("Library.Treeview.Heading", background=[("active", C["surface2"])])
        style.configure("Library.Horizontal.TProgressbar", background=C["aqua"], troughcolor=C["edge"],
                        bordercolor=C["edge"], thickness=6)
        style.configure("TCombobox", fieldbackground=C["surface"], background=C["surface2"],
                        foreground=C["text"], arrowcolor=C["sub"], bordercolor=C["edge"], padding=7)
        style.map("TCombobox", fieldbackground=[("readonly", C["surface"])],
                  foreground=[("readonly", C["text"])])
        style.configure("Vertical.TScrollbar", background=C["surface2"], troughcolor=C["panel"])
        style.configure("Horizontal.TScrollbar", background=C["surface2"], troughcolor=C["panel"])

    def _layout(self):
        main = tk.Frame(self, bg=C["bg"])
        main.pack(fill="both", expand=True)
        self.sidebar = tk.Frame(main, bg=C["side"], width=244)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        self._sidebar_header()
        self.nav_body = tk.Frame(self.sidebar, bg=C["side"])
        self.nav_body.pack(fill="both", expand=True)
        self._sidebar_footer()

        body = tk.Frame(main, bg=C["bg"])
        body.pack(side="left", fill="both", expand=True)
        header = tk.Frame(body, bg=C["bg"])
        header.pack(fill="x", padx=27, pady=(23, 13))
        title_wrap = tk.Frame(header, bg=C["bg"])
        title_wrap.pack(side="left", fill="x", expand=True)
        text(title_wrap, "File Manager", size=23, weight="bold").pack(anchor="w")
        text(title_wrap, "Your company documents, organized and searchable in one place.", size=10,
             color="sub").pack(anchor="w", pady=(3, 0))
        btn(header, "+ Add company", self.add_company, small=True).pack(side="right", padx=(8, 0))
        btn(header, "Import files", self.pick_files, accent=True, small=True).pack(side="right")

        bar = tk.Frame(body, bg=C["panel"], highlightbackground=C["edge"], highlightthickness=1)
        bar.pack(fill="x", padx=27, pady=(2, 16), ipady=4)
        text(bar, "⌕", size=20, color="aqua", bg="panel").pack(side="left", padx=(16, 6))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", self._schedule_search)
        self.search_input = tk.Entry(bar, textvariable=self.search_var, bg=C["panel"], fg=C["text"],
                                     insertbackground=C["aqua"], relief="flat", bd=0,
                                     font=(FONT, 12), highlightthickness=0)
        self.search_input.pack(side="left", fill="x", expand=True, padx=(0, 8), pady=11)
        self.search_input.bind("<FocusIn>", self._clear_placeholder)
        self.search_input.bind("<FocusOut>", self._show_placeholder)
        btn(bar, "✦ AI Find", self.ai_find, small=True).pack(side="right", padx=(4, 12), pady=4)
        text(bar, "Ctrl + K", size=9, color="muted", bg="panel").pack(side="right", padx=(0, 8))
        self.search_placeholder()

        metrics = tk.Frame(body, bg=C["bg"])
        metrics.pack(fill="x", padx=27, pady=(0, 16))
        self.kpi = []
        for i, (label, color) in enumerate((("All documents", "text"), ("Filed automatically", "aqua"),
                                             ("Needs review", "amber"), ("Companies", "blue"))):
            tile = tk.Frame(metrics, bg=C["panel"], highlightbackground=C["edge"], highlightthickness=1)
            tile.pack(side="left", fill="x", expand=True, padx=(0, 8 if i < 3 else 0))
            num = text(tile, "0", size=22, weight="bold", color=color, bg="panel")
            num.pack(anchor="w", padx=17, pady=(13, 0))
            text(tile, label, size=9, color="sub", bg="panel").pack(anchor="w", padx=17, pady=(0, 13))
            self.kpi.append(num)

        upload = tk.Frame(body, bg=C["panel"], highlightbackground=C["aqua"], highlightthickness=1)
        upload.pack(fill="x", padx=27, pady=(0, 15))
        up_left = tk.Frame(upload, bg=C["panel"])
        up_left.pack(side="left", fill="both", expand=True, padx=19, pady=14)
        text(up_left, "↥  Smart intake", size=14, weight="bold", color="aqua", bg="panel").pack(anchor="w")
        text(up_left, "Drop invoices, bank statements, contracts, payroll and more here.",
             size=10, color="text", bg="panel").pack(anchor="w", pady=(3, 2))
        self.drop_sub = text(up_left, "Detects company and document type  •  Finds duplicates  •  Flags uncertain matches",
                             size=9, color="sub", bg="panel")
        self.drop_sub.pack(anchor="w")
        btn(upload, "Browse files", self.pick_files, small=True).pack(side="right", padx=19)
        if DND_ENABLED:
            for widget in (upload, up_left, self.drop_sub):
                widget.drop_target_register(DND_FILES)
                widget.dnd_bind("<<Drop>>", self._on_drop)
        else:
            self.drop_sub.configure(text="Use Browse files. Drag-and-drop requires the bundled Windows build.")

        filter_bar = tk.Frame(body, bg=C["bg"])
        filter_bar.pack(fill="x", padx=27, pady=(0, 12))
        self.view_title = text(filter_bar, "All documents", size=15, weight="bold")
        self.view_title.pack(side="left")
        self.result_count = text(filter_bar, "", size=9, color="sub")
        self.result_count.pack(side="left", padx=(13, 0))
        btn(filter_bar, "Export CSV", self.export_csv, small=True).pack(side="right", padx=(6, 0))
        btn(filter_bar, "Open library", self.open_library, small=True).pack(side="right")

        bottom = tk.Frame(body, bg=C["bg"])
        bottom.pack(side="bottom", fill="x", padx=27, pady=(0, 12))
        self.status_label = text(bottom, "Ready • Documents stay on this PC", size=9, color="sub")
        self.status_label.pack(side="left")
        self.progress = ttk.Progressbar(bottom, mode="determinate", length=190, style="Library.Horizontal.TProgressbar")
        self.progress.pack(side="right")
        # Give the file list the working area, rather than opening at a 50/50 split.
        self.after(160, self._initial_sash)


        content = tk.PanedWindow(body, orient="horizontal", bg=C["bg"], bd=0, sashwidth=5,
                                 sashrelief="flat", opaqueresize=True)
        content.pack(fill="both", expand=True, padx=27, pady=(0, 12))
        self.content_pane = content
        results_frame = tk.Frame(content, bg=C["panel"], highlightbackground=C["edge"], highlightthickness=1)
        content.add(results_frame, minsize=450, stretch="always")
        columns = ("title", "company", "category", "date", "status")
        self.tree = ttk.Treeview(results_frame, columns=columns, show="headings", style="Library.Treeview", selectmode="extended")
        for col, title, width, stretch in [
            ("title", "DOCUMENT", 235, True), ("company", "COMPANY", 155, True),
            ("category", "TYPE", 135, False), ("date", "DATE", 92, False),
            ("status", "STATUS", 85, False),
        ]:
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, minwidth=70, stretch=stretch, anchor="w")
        scroll = ttk.Scrollbar(results_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.show_selection)
        self.tree.bind("<Double-1>", lambda _: self.open_file())
        self.tree.bind("<Return>", lambda _: self.open_file())
        self.tree.bind("<Button-3>", self.context_menu)
        self.context = tk.Menu(self, tearoff=False, bg=C["panel"], fg=C["text"],
                               activebackground=C["surface2"], activeforeground=C["text"], bd=1)
        self.context.add_command(label="Open document", command=self.open_file)
        self.context.add_command(label="Show in folder", command=self.reveal_file)
        self.context.add_command(label="Assign / change company", command=self.assign_selected)
        self.context.add_command(label="Edit tags", command=self.edit_tags)

        detail = tk.Frame(content, bg=C["panel"], width=293, highlightbackground=C["edge"], highlightthickness=1)
        content.add(detail, minsize=260, stretch="never")
        top = tk.Frame(detail, bg=C["panel"])
        top.pack(fill="x", padx=17, pady=(18, 6))
        text(top, "FILE DETAILS", size=10, weight="bold", color="sub", bg="panel").pack(anchor="w")
        self.details_title = text(detail, "Select a document", size=13, weight="bold", bg="panel",
                                  wraplength=240, justify="left", anchor="w")
        self.details_title.pack(fill="x", padx=17, pady=(8, 10))
        self.details_meta = text(detail, "Preview its company, references and document text here.",
                                 size=9, color="sub", bg="panel", wraplength=245,
                                 justify="left", anchor="nw")
        self.details_meta.pack(fill="x", padx=17, pady=(0, 8))
        text(detail, "EXTRACTED TEXT", size=9, weight="bold", color="muted", bg="panel").pack(anchor="w", padx=17, pady=(7, 7))
        preview_frame = tk.Frame(detail, bg=C["surface"])
        preview_frame.pack(fill="both", expand=True, padx=13, pady=(0, 10))
        self.preview = tk.Text(preview_frame, bg=C["surface"], fg=C["sub"], insertbackground=C["text"],
                               font=(FONT, 9), wrap="word", relief="flat", highlightthickness=0,
                               padx=10, pady=10, state="disabled", height=12)
        self.preview.pack(fill="both", expand=True)
        actions = tk.Frame(detail, bg=C["panel"])
        actions.pack(fill="x", padx=13, pady=(0, 12))
        btn(actions, "Open file", self.open_file, accent=True, small=True).pack(fill="x", pady=(0, 6))
        btn(actions, "Assign / reassign", self.assign_selected, small=True).pack(fill="x", pady=(0, 6))
        btn(actions, "Open containing folder", self.reveal_file, small=True).pack(fill="x")


    def _initial_sash(self):
        try:
            width = self.content_pane.winfo_width()
            if width > 700:
                self.content_pane.sash_place(0, width - 325, 0)
        except tk.TclError:
            pass

    def search_placeholder(self):
        self.placeholder = "Search company, voucher number, invoice reference, keywords, month…"
        self.placeholder_active = False
        self._show_placeholder()

    def _show_placeholder(self, event=None):
        if not self.search_var.get() and self.focus_get() != self.search_input:
            self.placeholder_active = True
            self.search_input.configure(fg=C["muted"])
            self.search_var.set(self.placeholder)

    def _clear_placeholder(self, event=None):
        if self.placeholder_active:
            self.placeholder_active = False
            self.search_var.set("")
            self.search_input.configure(fg=C["text"])

    def _typed_query(self):
        return "" if self.placeholder_active else self.search_var.get().strip()

    def _sidebar_header(self):
        header = tk.Frame(self.sidebar, bg=C["side"])
        header.pack(fill="x", padx=18, pady=(24, 25))
        badge = tk.Label(header, text="FM", font=(FONT, 16, "bold"), bg=C["aqua"], fg=C["white"],
                         width=3, height=2)
        badge.pack(side="left", padx=(0, 11))
        block = tk.Frame(header, bg=C["side"])
        block.pack(side="left")
        text(block, "FILE MANAGER", size=12, weight="bold", bg="side").pack(anchor="w")
        text(block, "SMART COMPANY LIBRARY", size=7, color="sub", bg="side").pack(anchor="w", pady=(2, 0))
        tk.Frame(self.sidebar, bg=C["edge"], height=1).pack(fill="x", padx=16)

    def _sidebar_footer(self):
        tk.Frame(self.sidebar, bg=C["edge"], height=1).pack(fill="x", padx=16, pady=12)
        actions = tk.Frame(self.sidebar, bg=C["side"])
        actions.pack(fill="x", padx=16, pady=(0, 14))
        btn(actions, "⚙  Settings", self.show_settings, small=True).pack(fill="x", pady=(0, 6))
        btn(actions, "◷  Backup index", self.backup_index, small=True).pack(fill="x")
        text(self.sidebar, "LOCAL STORAGE  •  v1.1 LIGHT", size=8, color="muted", bg="side").pack(pady=(0, 17))

    def _nav_button(self, parent, label, action, active=False, count=None):
        wrap = tk.Frame(parent, bg=C["surface2"] if active else C["side"])
        wrap.pack(fill="x", pady=2)
        value = f"{label}   {count}" if count is not None else label
        tk.Button(wrap, text=value, command=action, anchor="w", bg=wrap["bg"],
                  fg=C["aqua"] if active else C["text"], activebackground=C["surface2"],
                  activeforeground=C["aqua"], relief="flat", bd=0, cursor="hand2",
                  font=(FONT, 10, "bold" if active else "normal"), padx=12, pady=10).pack(fill="x")

    def _rebuild_nav(self):
        for child in self.nav_body.winfo_children():
            child.destroy()
        overview = tk.Frame(self.nav_body, bg=C["side"])
        overview.pack(fill="x", padx=14, pady=(16, 6))
        text(overview, "OVERVIEW", size=9, weight="bold", color="muted", bg="side").pack(anchor="w", pady=(0, 7))
        totals = self.core.summary()
        for key, label, number in [
            ("all", "▦   All documents", totals["total"]),
            ("review", "◷   Needs review", totals["review"]),
            ("recent", "◫   Recent files", None),
        ]:
            self._nav_button(overview, label, lambda k=key: self.set_view(k), self.current_view == key and self.active_company is None, number)
        companyarea = tk.Frame(self.nav_body, bg=C["side"])
        companyarea.pack(fill="x", padx=14, pady=(19, 0))
        header = tk.Frame(companyarea, bg=C["side"])
        header.pack(fill="x", pady=(0, 8))
        text(header, "COMPANIES", size=9, weight="bold", color="muted", bg="side").pack(side="left")
        tk.Button(header, text="+", command=self.add_company, bg=C["side"], fg=C["aqua"],
                  activebackground=C["surface2"], activeforeground=C["aqua"], font=(FONT, 14, "bold"),
                  bd=0, cursor="hand2").pack(side="right")
        company_canvas = tk.Canvas(companyarea, bg=C["side"], highlightthickness=0, height=285)
        bar = ttk.Scrollbar(companyarea, orient="vertical", command=company_canvas.yview)
        scrollable = tk.Frame(company_canvas, bg=C["side"])
        window = company_canvas.create_window((0, 0), window=scrollable, anchor="nw")
        scrollable.bind("<Configure>", lambda e: company_canvas.configure(scrollregion=company_canvas.bbox("all")))
        company_canvas.bind("<Configure>", lambda e: company_canvas.itemconfig(window, width=e.width))
        company_canvas.configure(yscrollcommand=bar.set)
        company_canvas.pack(side="left", fill="both", expand=True)
        bar.pack(side="right", fill="y")
        for company in self.core.companies():
            cid = company["id"]
            self._nav_button(scrollable, "▣   " + company["name"], lambda c=cid: self.set_company(c),
                             self.active_company == cid, company["file_count"])
        self._nav_button(companyarea, "✎   Manage companies", self.manage_companies)

    def _refresh(self):
        totals = self.core.summary()
        for label, val in zip(self.kpi, (totals["total"], totals["filed"], totals["review"], totals["companies"])):
            label.configure(text=str(val))
        self._rebuild_nav()
        self.perform_search()

    def _schedule_search(self, *_):
        self.ai_search_payload = None
        if self.search_after:
            self.after_cancel(self.search_after)
        self.search_after = self.after(220, self.perform_search)

    def ai_find(self):
        query = self._typed_query()
        if not query:
            self.focus_search()
            return
        if not self.ai.available():
            messagebox.showinfo("Enable AI Find", "Offline search already works without an API key.\n\nTo use AI query understanding, enable cloud AI and enter your OpenAI API key in Settings. Only the search terms and company names are transmitted.")
            return
        self.status_label.configure(text="AI is interpreting your document search…", fg=C["aqua"])
        def worker():
            try:
                result = self.ai.expand_search(query, self.core.companies())
                self.messages.put(("ai-search", query, result))
            except Exception as exc:
                self.messages.put(("ai-error", str(exc)))
        threading.Thread(target=worker, daemon=True, name="FileManagerAISearch").start()

    def focus_search(self):
        self.search_input.focus_set()
        self._clear_placeholder()
        self.search_input.select_range(0, "end")

    def set_view(self, view):
        self.current_view = view
        self.active_company = None
        self._refresh()

    def set_company(self, company_id):
        self.active_company = company_id
        self.current_view = "company"
        self._refresh()

    def perform_search(self):
        if not hasattr(self, "tree"):
            return
        query = self._typed_query()
        company_id = self.active_company
        if self.ai_search_payload:
            query = self.ai_search_payload["query"]
            if company_id is None:
                company_id = self.ai_search_payload.get("company_id")
        state = "review" if self.current_view == "review" else "all"
        self.search_rows = self.core.search(query=query, company_id=company_id, state=state)
        if self.current_view == "recent" and not query:
            self.search_rows = self.search_rows[:50]
        for item in self.tree.get_children():
            self.tree.delete(item)
        for row in self.search_rows:
            self.tree.insert("", "end", iid=str(row["id"]), values=(
                row["title"], row["company_name"], row["category"],
                row["document_date"] or "—", "✓ Filed" if row["state"] == "filed" else "! Review",
            ))
        if self.active_company is not None:
            c = self.core.get_company(self.active_company)
            name = c["name"]
        else:
            name = {"all": "All documents", "review": "Documents needing review", "recent": "Recently added"}.get(self.current_view, "All documents")
        self.view_title.configure(text=name)
        self.result_count.configure(text=f"{len(self.search_rows)} results")
        if self.selected_id and self.tree.exists(str(self.selected_id)):
            self.tree.selection_set(str(self.selected_id))
        else:
            self.selected_id = None
            self.show_selection()

    def show_selection(self, *_):
        selected = self.tree.selection()
        if not selected:
            self.details_title.configure(text="Select a document")
            self.details_meta.configure(text="Preview its company, references and document text here.")
            self._preview("")
            return
        self.selected_id = int(selected[0])
        try:
            doc = self.core.document(self.selected_id)
        except ValueError:
            return
        self.details_title.configure(text=doc["title"])
        self.details_meta.configure(text=(
            f"COMPANY  {doc['company_name'] or 'Not assigned'}\n"
            f"CATEGORY  {doc['category']}\n"
            f"DATE  {doc['document_date'] or 'Not detected'}\n"
            f"REFERENCES  {doc['ref'] or '—'}\n"
            f"TAGS  {doc['tags'] or '—'}\n"
            f"STATUS  {'Filed' if doc['state'] == 'filed' else 'Needs review'}\n"
            f"MATCH  {doc['confidence']:.0%}  •  {doc['reason']}"
        ))
        preview = doc["content"][:3300] or "No selectable document text.\n\nThis may be a scanned image, legacy Office file, or unsupported text format.\nThe filename and references are still searchable."
        self._preview(preview)

    def _preview(self, value):
        self.preview.configure(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", value)
        self.preview.configure(state="disabled")

    def _on_drop(self, event):
        paths = [Path(p) for p in self.tk.splitlist(event.data)]
        self.start_import(paths)

    def pick_files(self):
        paths = filedialog.askopenfilenames(title="Select documents to import", filetypes=[("All supported documents", "*.pdf *.doc *.docx *.xls *.xlsx *.xlsm *.csv *.txt *.rtf *.eml *.msg *.png *.jpg *.jpeg *.tif *.tiff *.bmp *.pptx *.html *.json"), ("All files", "*.*")])
        if paths:
            self.start_import([Path(p) for p in paths])

    def start_import(self, paths):
        if self.busy:
            messagebox.showinfo("Import in progress", "An import is already running.")
            return
        if not paths:
            return
        self.busy = True
        self.progress.configure(value=0)
        self.status_label.configure(text="Analyzing documents and preparing safe copies…", fg=C["aqua"])
        ai_callback = self.ai.classify if self.ai.available() else None
        def worker():
            def on_step(i, total, item):
                self.messages.put(("progress", i, total, item))
            try:
                results = self.core.import_many(paths, callback=on_step, ai=ai_callback,
                     move_original=bool(self.settings.data["move_original"]),
                     auto_file=bool(self.settings.data["auto_file"]))
                self.messages.put(("done", results))
            except Exception as exc:
                self.messages.put(("error", f"Import failed: {exc}"))
        threading.Thread(target=worker, daemon=True, name="FileManagerIntake").start()

    def _poll(self):
        try:
            while True:
                item = self.messages.get_nowait()
                if item[0] == "progress":
                    _, i, total, result = item
                    self.progress.configure(value=100 * i / max(total, 1))
                    self.status_label.configure(text=f"Imported {i}/{total} • {result.get('name','')[:55]}")
                elif item[0] == "done":
                    self.busy = False
                    results = item[1]
                    filed = sum(r["status"] == "filed" for r in results)
                    review = sum(r["status"] == "review" for r in results)
                    duplicate = sum(r["status"] == "duplicate" for r in results)
                    err = [r for r in results if r["status"] == "error"]
                    self.status_label.configure(text=f"Finished • {filed} filed • {review} to review • {duplicate} duplicates • {len(err)} errors",
                                                fg=C["aqua"] if not err else C["amber"])
                    self._refresh()
                    if review:
                        self.set_view("review")
                    if err:
                        messagebox.showwarning("Import completed with errors", "\n".join(f"{r['name']}: {r['message']}" for r in err[:10]))
                elif item[0] == "ai-search":
                    _, original_query, response = item
                    # Do not overwrite a newer query while the network request is running.
                    if original_query == self._typed_query():
                        # Search normally scores across all words with OR semantics. The
                        # original reference remains first and gets the strongest match.
                        terms = [original_query, *response.get("terms", [])]
                        searchtext = " ".join(dict.fromkeys(terms))
                        if response.get("year"):
                            searchtext += " year:" + response["year"]
                        if response.get("category"):
                            searchtext += " type:" + response["category"].split()[0]
                        self.ai_search_payload = {"query": searchtext, "company_id": response.get("company_id")}
                        self.perform_search()
                        self.status_label.configure(text="AI Find • Interpreted: " + ", ".join(response.get("terms", []))[:95], fg=C["aqua"])
                elif item[0] == "ai-error":
                    self.status_label.configure(text="AI unavailable • local search still active", fg=C["amber"])
                    messagebox.showwarning("AI Find unavailable", item[1])
                elif item[0] == "error":
                    self.busy = False
                    self.status_label.configure(text="Import failed", fg=C["red"])
                    messagebox.showerror("Error", item[1])
        except queue.Empty:
            pass
        self.after(140, self._poll)

    def selected_doc(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("Select a file", "Select a document in the list first.")
            return None
        return self.core.document(int(selection[0]))

    def open_file(self):
        d = self.selected_doc()
        if d:
            p = Path(d["absolute_path"])
            if not p.exists():
                messagebox.showerror("Missing file", "The source document cannot be found. Check your library drive.")
                return
            try:
                if os.name == "nt":
                    os.startfile(p)
                else:
                    subprocess.Popen(["xdg-open", str(p)])
            except Exception as exc:
                messagebox.showerror("Cannot open document", str(exc))

    def reveal_file(self):
        d = self.selected_doc()
        if d:
            self._open_folder(Path(d["absolute_path"]).parent)

    def _open_folder(self, path):
        try:
            if os.name == "nt":
                os.startfile(path)
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Cannot open folder", str(exc))

    def open_library(self):
        self._open_folder(self.core.root)

    def context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context.tk_popup(event.x_root, event.y_root)

    def assign_selected(self):
        ids = [int(v) for v in self.tree.selection()]
        if not ids:
            messagebox.showinfo("Select a file", "Choose a document to assign.")
            return
        win = self._dialog("Assign / reassign document", 460, 400)
        text(win, f"Company for {len(ids)} selected document(s)", size=12, weight="bold", bg="panel").pack(anchor="w", padx=22, pady=(22, 8))
        companies = self.core.companies()
        if not companies:
            win.destroy()
            messagebox.showinfo("No companies", "Create a company first.")
            return
        choices = [c["name"] for c in companies]
        selected = tk.StringVar(value=choices[0])
        combo = ttk.Combobox(win, values=choices, textvariable=selected, state="readonly", font=(FONT, 11))
        combo.pack(fill="x", padx=22, pady=8)
        text(win, "Document category", size=10, color="sub", bg="panel").pack(anchor="w", padx=22, pady=(12, 4))
        current = self.core.document(ids[0])
        category = tk.StringVar(value=current["category"] if current["category"] in CATEGORIES else "Other")
        ttk.Combobox(win, values=list(CATEGORIES), textvariable=category, state="readonly", font=(FONT, 10)).pack(fill="x", padx=22)
        text(win, "Files will be moved within your library. Originals already outside the library remain untouched.",
             size=9, color="sub", bg="panel", wraplength=410, justify="left").pack(anchor="w", padx=22, pady=19)
        def apply():
            cid = next(c["id"] for c in companies if c["name"] == selected.get())
            try:
                for doc_id in ids:
                    self.core.approve(doc_id, cid, category.get(), move_original=bool(self.settings.data["move_original"]))
                win.destroy()
                self._refresh()
                self.status_label.configure(text=f"Assigned {len(ids)} document(s) to {selected.get()}", fg=C["aqua"])
            except Exception as exc:
                messagebox.showerror("Assignment error", str(exc), parent=win)
        btn(win, "Confirm filing", apply, accent=True).pack(fill="x", padx=22, pady=9)

    def edit_tags(self):
        d = self.selected_doc()
        if not d:
            return
        value = simpledialog.askstring("Search tags", "Add searchable keywords (comma separated):", initialvalue=d["tags"], parent=self)
        if value is not None:
            self.core.change_tags(d["id"], value)
            self._refresh()

    def _dialog(self, title, width=480, height=400):
        win = tk.Toplevel(self)
        win.configure(bg=C["panel"])
        win.title(title)
        win.geometry(f"{width}x{height}")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()
        return win

    def add_company(self):
        self.company_editor()

    def manage_companies(self):
        companies = self.core.companies()
        if not companies:
            self.add_company()
            return
        win = self._dialog("Manage companies", 470, 460)
        text(win, "Manage company sections", size=16, weight="bold", bg="panel").pack(anchor="w", padx=20, pady=(20, 9))
        listing = tk.Listbox(win, font=(FONT, 11), bg=C["surface"], fg=C["text"],
                             selectbackground=C["surface2"], selectforeground=C["aqua"],
                             bd=0, highlightthickness=0, height=12)
        listing.pack(fill="both", expand=True, padx=20, pady=7)
        for company in companies:
            listing.insert("end", f"{company['name']}   ({company['file_count']} files)")
        actions = tk.Frame(win, bg=C["panel"])
        actions.pack(fill="x", padx=20, pady=(6, 20))
        def edit():
            selected = listing.curselection()
            if selected:
                win.destroy()
                self.company_editor(companies[selected[0]])
        def remove():
            selected = listing.curselection()
            if not selected:
                return
            company = companies[selected[0]]
            if messagebox.askyesno("Remove empty company", f"Remove '{company['name']}' section?\nNo documents will be deleted.", parent=win):
                try:
                    self.core.remove_company(company["id"])
                    win.destroy()
                    self.active_company = None
                    self._refresh()
                except Exception as exc:
                    messagebox.showerror("Cannot remove company", str(exc), parent=win)
        btn(actions, "Edit aliases", edit, small=True).pack(side="left", padx=(0, 6))
        btn(actions, "Remove empty", remove, small=True, danger=True).pack(side="left")
        btn(actions, "+ Add", lambda: (win.destroy(), self.add_company()), small=True, accent=True).pack(side="right")

    def company_editor(self, company=None):
        win = self._dialog("Edit company" if company else "Add company", 490, 375)
        text(win, "Edit company" if company else "Add a company", size=17, weight="bold", bg="panel").pack(anchor="w", padx=23, pady=(23, 15))
        text(win, "Company name", size=10, color="sub", bg="panel").pack(anchor="w", padx=23)
        name = tk.Entry(win, font=(FONT, 12), bg=C["surface2"], fg=C["text"],
                        insertbackground=C["aqua"], relief="flat", bd=0)
        name.pack(fill="x", padx=23, ipady=9, pady=(7, 15))
        text(win, "Aliases / abbreviations (comma-separated)", size=10, color="sub", bg="panel").pack(anchor="w", padx=23)
        aliases = tk.Entry(win, font=(FONT, 11), bg=C["surface2"], fg=C["text"],
                           insertbackground=C["aqua"], relief="flat", bd=0)
        aliases.pack(fill="x", padx=23, ipady=8, pady=(7, 8))
        text(win, "Example: The Graphitees WLL → graphitees, TGWLL, graphitees trading",
             size=9, color="muted", bg="panel", wraplength=430, justify="left").pack(anchor="w", padx=23)
        if company:
            name.insert(0, company["name"])
            aliases.insert(0, company["aliases"])
        def save():
            try:
                if company:
                    self.core.update_company(company["id"], name.get(), aliases.get())
                else:
                    self.core.add_company(name.get(), aliases.get())
                win.destroy()
                self._refresh()
            except Exception as exc:
                messagebox.showerror("Company error", str(exc), parent=win)
        btn(win, "Save company", save, accent=True).pack(fill="x", padx=23, pady=25)
        name.focus_set()

    def show_settings(self):
        win = self._dialog("Settings", 610, 625)
        text(win, "Settings & privacy", size=17, weight="bold", bg="panel").pack(anchor="w", padx=22, pady=(19, 13))
        text(win, "DOCUMENT LIBRARY FOLDER", size=9, weight="bold", color="muted", bg="panel").pack(anchor="w", padx=22)
        root_var = tk.StringVar(value=self.settings.data["library_root"])
        location = tk.Frame(win, bg=C["panel"])
        location.pack(fill="x", padx=22, pady=(7, 12))
        entry = tk.Entry(location, textvariable=root_var, font=(FONT, 9), bg=C["surface2"], fg=C["text"],
                         insertbackground=C["text"], relief="flat")
        entry.pack(side="left", fill="x", expand=True, ipady=9)
        btn(location, "Choose", lambda: (lambda d: root_var.set(d) if d else None)(filedialog.askdirectory(parent=win)), small=True).pack(side="right", padx=(7, 0))
        text(win, "FILE HANDLING", size=9, weight="bold", color="muted", bg="panel").pack(anchor="w", padx=22, pady=(9, 7))
        original = tk.BooleanVar(value=self.settings.data["move_original"])
        automatic = tk.BooleanVar(value=self.settings.data["auto_file"])
        self._check(win, "Move original files after verified filing (otherwise keep originals)", original)
        self._check(win, "Automatically file only high-confidence company matches", automatic)
        text(win, "OPTIONAL CLOUD AI", size=9, weight="bold", color="muted", bg="panel").pack(anchor="w", padx=22, pady=(18, 7))
        ai_var = tk.BooleanVar(value=self.settings.data["ai_enabled"])
        self._check(win, "Use OpenAI to analyze extracted text during intake", ai_var)
        text(win, "Only a document excerpt (up to 10,000 characters) is sent to OpenAI.\nScanned images and entire documents are NOT uploaded.",
             size=9, color="sub", bg="panel", justify="left").pack(anchor="w", padx=43, pady=(2, 10))
        text(win, "API key (encrypted for your Windows account)", size=9, color="sub", bg="panel").pack(anchor="w", padx=22)
        key = tk.Entry(win, show="•", font=(FONT, 10), bg=C["surface2"], fg=C["text"], relief="flat")
        key.pack(fill="x", padx=22, ipady=9, pady=(5, 4))
        key.insert(0, "")
        text(win, "Leave empty to keep existing key. Type CLEAR to remove it.", size=8, color="muted", bg="panel").pack(anchor="w", padx=22)
        model_var = tk.StringVar(value=self.settings.data["ai_model"])
        model_row = tk.Frame(win, bg=C["panel"])
        model_row.pack(fill="x", padx=22, pady=(10, 4))
        text(model_row, "AI model", size=9, color="sub", bg="panel").pack(side="left")
        tk.Entry(model_row, textvariable=model_var, bg=C["surface2"], fg=C["text"], relief="flat",
                 font=(FONT, 10), width=25).pack(side="right", ipady=6)
        def save():
            newroot = str(Path(root_var.get()).expanduser().resolve())
            if newroot != str(self.core.root):
                if self.busy:
                    messagebox.showerror("Busy", "Finish importing before switching libraries.", parent=win)
                    return
                if not messagebox.askyesno("Switch library", "Switch to a different library?\nExisting files will stay safely in the previous library; they will not be transferred.", parent=win):
                    return
            try:
                if key.get().strip().upper() == "CLEAR":
                    self.settings.set_key("")
                elif key.get().strip():
                    self.settings.set_key(key.get().strip())
                self.settings.data.update({"library_root": newroot, "move_original": original.get(),
                     "auto_file": automatic.get(), "ai_enabled": ai_var.get(), "ai_model": model_var.get().strip() or "gpt-4o-mini"})
                self.settings.save()
                if newroot != str(self.core.root):
                    new_core = FileManagerCore(Path(newroot), seed_companies=self.settings.data["seed_companies"])
                    self.core.close()
                    self.core = new_core
                    self.set_view("all")
                win.destroy()
                self._refresh()
            except Exception as exc:
                messagebox.showerror("Settings error", str(exc), parent=win)
        btn(win, "Save settings", save, accent=True, small=True).pack(fill="x", padx=22, pady=(8, 11))

    def _check(self, parent, value, variable):
        tk.Checkbutton(parent, text=value, variable=variable, bg=C["panel"], fg=C["text"],
                       selectcolor=C["surface2"], activebackground=C["panel"], activeforeground=C["aqua"],
                       font=(FONT, 9), anchor="w", highlightthickness=0, bd=0).pack(fill="x", padx=22, pady=3)

    def export_csv(self):
        target = filedialog.asksaveasfilename(title="Export current document list", defaultextension=".csv",
              initialfile="File_Manager_Index.csv", filetypes=[("CSV files", "*.csv")])
        if target:
            try:
                self.core.export_index_csv(Path(target), self.search_rows)
                self.status_label.configure(text=f"Exported {len(self.search_rows)} records", fg=C["aqua"])
            except Exception as exc:
                messagebox.showerror("Export error", str(exc))

    def backup_index(self):
        target = filedialog.asksaveasfilename(title="Backup searchable index (does not include documents)",
               defaultextension=".sqlite", initialfile="FileManager_Index_Backup.sqlite", filetypes=[("SQLite database", "*.sqlite")])
        if target:
            try:
                self.core.backup_index(Path(target))
                messagebox.showinfo("Index backed up", "The searchable index was backed up successfully.\n\nYour actual documents are still in the selected library folder. Back up that folder as well.")
            except Exception as exc:
                messagebox.showerror("Backup error", str(exc))

    def close_app(self):
        if self.busy:
            messagebox.showinfo("Finishing import", "An import is running. Close the app after it completes to keep your library consistent.")
            return
        self.core.close()
        self.destroy()


def main():
    """Show a real diagnostic instead of silently exiting in a windowed executable."""
    import traceback
    try:
        app = FileManagerApp()
        app.mainloop()
    except Exception:
        from datetime import datetime
        details = traceback.format_exc()
        logdir = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "NextFileManager"
        try:
            logdir.mkdir(parents=True, exist_ok=True)
            logfile = logdir / "error.log"
            with logfile.open("a", encoding="utf-8") as log:
                log.write("\n" + datetime.now().isoformat() + "\n" + details + "\n")
        except OSError:
            logfile = Path("error.log")
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,
                "File Manager could not open.\n\n" + details[-1300:] +
                "\n\nError report: " + str(logfile), "File Manager - Startup Error", 0x10)
        else:
            print(details, flush=True)
        raise
