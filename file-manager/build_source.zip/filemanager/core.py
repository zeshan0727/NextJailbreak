"""Document indexing, local classification, safe filing, and intelligent retrieval.
All disk changes are confined to the selected library and staged from originals.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import sqlite3
import threading
import unicodedata
import uuid
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from xml.etree import ElementTree as ET

APP_NAME = "File Manager"
CATEGORIES = (
    "Invoices & Bills", "Payment Vouchers", "Receipts", "Bank Statements",
    "Purchase Orders", "Contracts", "Payroll", "Human Resources",
    "Tax & Compliance", "Audit & Financials", "Correspondence", "Other",
)
SUPPORTED = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".xlsm", ".csv",
    ".txt", ".rtf", ".eml", ".msg", ".png", ".jpg", ".jpeg",
    ".tif", ".tiff", ".bmp", ".pptx", ".html", ".htm", ".json",
}
DEFAULT_COMPANIES = [
    ("Barjous Architects", "barjous,barjous architects,barjous architects engineering consultancy"),
    ("The Graphitees WLL", "graphitees,the graphitees"),
    ("Stone Café", "stone cafe,stone café"),
    ("Levante Bags", "levante,levante bags,levante bags for trading"),
    ("Atelier Homes", "atelier homes,atelier home"),
    ("Erada Fitness", "erada,erada fitness"),
    ("North Sports Fitness", "north sports,north sports fitness"),
]
CATEGORY_PATTERNS = {
    "Payment Vouchers": [r"\bpayment\s+voucher\b", r"\bpv[\s_-]?[a-z]{0,3}[\s_-]?\d{2,}\b", r"\bpayment advice\b"],
    "Bank Statements": [r"\bbank\s+statement\b", r"\baccount\s+statement\b", r"\bopening\s+balance\b.{0,50}\bclosing\s+balance\b"],
    "Invoices & Bills": [r"\btax\s+invoice\b", r"\bcommercial\s+invoice\b", r"\binvoice\b", r"\bbill\s+(?:no|number)\b", r"\binv[\s_-]?\d{2,}\b"],
    "Receipts": [r"\bofficial\s+receipt\b", r"\breceipt\b", r"\breceived\s+(?:from|by)\b"],
    "Purchase Orders": [r"\bpurchase\s+order\b", r"\bpo[\s_-]?\d{3,}\b"],
    "Contracts": [r"\bcontract\b", r"\bagreement\b", r"\bmemorandum\s+of\s+understanding\b"],
    "Payroll": [r"\bpayroll\b", r"\bsalary\s+sheet\b", r"\bpay\s*slip\b", r"\bwps\b"],
    "Human Resources": [r"\bleave\s+settlement\b", r"\bemployee\s+(?:record|contract)\b", r"\bgratuity\b", r"\bfinal\s+settlement\b"],
    "Tax & Compliance": [r"\bwithholding\s+tax\b", r"\bwht\b", r"\bvat\b", r"\btax\s+return\b", r"\bdhareeba\b"],
    "Audit & Financials": [r"\btrial\s+balance\b", r"\bbalance\s+sheet\b", r"\bincome\s+statement\b", r"\baudit\b", r"\bfinancial\s+statement\b"],
    "Correspondence": [r"\bdear\s+(?:sir|madam|team)\b", r"\bregards\b", r"\bsubject\s*:\b"],
}
MONTHS = {"january":1,"jan":1,"february":2,"feb":2,"march":3,"mar":3,"april":4,"apr":4,
          "may":5,"june":6,"jun":6,"july":7,"jul":7,"august":8,"aug":8,"september":9,
          "sep":9,"sept":9,"october":10,"oct":10,"november":11,"nov":11,"december":12,"dec":12}
STOPWORDS = {"find", "show", "me", "the", "file", "files", "document", "documents", "for", "of", "from", "in", "about", "please", "my", "all", "and", "with", "related", "to", "that", "where", "is", "a", "an", "get", "open"}


def normalized(s: str) -> str:
    return unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().casefold()


def tokens(s: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", normalized(s))


def safe_folder(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', " ", name).strip(" .")
    name = re.sub(r"\s+", " ", name)
    if name.upper() in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        name += " Folder"
    return name[:85] or "Unnamed"


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _xml_zip_text(path: Path, suffix: str) -> str:
    parts = []
    with zipfile.ZipFile(path) as archive:
        members = archive.namelist()
        if suffix == ".docx":
            names = [n for n in members if n == "word/document.xml" or re.fullmatch(r"word/(header|footer)\d+.xml", n)]
        elif suffix in {".xlsx", ".xlsm"}:
            names = [n for n in members if n == "xl/sharedStrings.xml" or re.fullmatch(r"xl/worksheets/sheet\d+.xml", n)]
        else:
            names = [n for n in members if re.fullmatch(r"ppt/slides/slide\d+.xml", n)]
        for name in names[:65]:
            try:
                root = ET.fromstring(archive.read(name))
                values = [elem.text.strip() for elem in root.iter() if elem.tag.rsplit("}", 1)[-1] in {"t", "v"} and elem.text and elem.text.strip()]
                parts.append(" ".join(values[:25000]))
            except Exception:
                continue
    return "\n".join(parts)[:125000]


def configure_tesseract(tesseract_module):
    if os.name == "nt":
        for candidate in (
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe",
            Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Tesseract-OCR" / "tesseract.exe",
        ):
            if candidate.exists():
                tesseract_module.pytesseract.tesseract_cmd = str(candidate)
                break


def extract_text(path: Path) -> str:
    """Local best-effort extraction; exceptions do not prevent safe filing."""
    ext = path.suffix.casefold()
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(str(path))
            result = []
            for page in reader.pages[:40]:
                result.append(page.extract_text(extraction_mode="plain") or "")
                if sum(map(len, result)) > 125000:
                    break
            extracted = "\n".join(result)[:125000]
            if len(extracted.strip()) < 40:
                # Optional free OCR for scanned PDFs. Requires Tesseract installed separately.
                try:
                    import io
                    import fitz
                    import pytesseract
                    from PIL import Image
                    configure_tesseract(pytesseract)
                    with fitz.open(path) as pdf:
                        scanned = []
                        for page in [pdf[i] for i in range(min(5, len(pdf)))]:
                            pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
                            scanned.append(pytesseract.image_to_string(Image.open(io.BytesIO(pix.tobytes("png")))))
                    extracted = (extracted + "\n" + "\n".join(scanned))[:125000]
                except Exception:
                    pass
            return extracted
        if ext in {".docx", ".xlsx", ".xlsm", ".pptx"}:
            return _xml_zip_text(path, ext)
        if ext in {".txt", ".csv", ".eml", ".json", ".html", ".htm", ".rtf"}:
            with path.open("rb") as f:
                raw = f.read(160000)
            if b"\x00" in raw[:200]:
                return ""
            decoded = raw.decode("utf-8-sig", errors="replace")
            if ext in {".html", ".htm"}:
                decoded = re.sub(r"(?is)<script.*?</script>|<style.*?</style>", " ", decoded)
                decoded = re.sub(r"<[^>]+>", " ", decoded)
            if ext == ".rtf":
                decoded = re.sub(r"\\[a-zA-Z]+-?\d*\s?", " ", decoded)
            return decoded[:125000]
        if ext in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
            try:
                import pytesseract
                from PIL import Image
                configure_tesseract(pytesseract)
                return pytesseract.image_to_string(Image.open(path))[:125000]
            except Exception:
                return ""
    except Exception:
        return ""
    return ""


def reference_candidates(text: str) -> str:
    regexes = [
        r"\b(?:INV|PV|RV|PO|SOA|LV)[-/ ]?[A-Z0-9/\-]*\d[A-Z0-9/\-]{2,30}\b",
        r"\b(?:invoice|reference|voucher|receipt|contract)\s*(?:no\.?|number|#|ref\.?)?\s*[:#-]\s*([A-Z0-9][A-Z0-9\-/]{3,35})",
    ]
    found = []
    for pat in regexes:
        for match in re.finditer(pat, text[:35000], re.IGNORECASE):
            candidate = match.group(1) if match.lastindex else match.group(0)
            if candidate not in found:
                found.append(candidate)
                if len(found) >= 8:
                    break
    return ", ".join(found)


def infer_date(s: str, modified: float) -> str:
    for pat in [r"\b(20\d{2})[-/.](0?[1-9]|1[0-2])[-/.]([0-2]?\d|3[01])\b", r"\b([0-2]?\d|3[01])[-/.](0?[1-9]|1[0-2])[-/.](20\d{2})\b"]:
        for m in re.finditer(pat, s[:12000]):
            nums = list(map(int, m.groups()))
            y, mm, dd = nums if nums[0] > 2000 else (nums[2], nums[1], nums[0])
            try:
                valid = dt.date(y, mm, dd)
                if 2015 <= y <= dt.datetime.now().year + 2:
                    return valid.isoformat()
            except ValueError:
                continue
    return dt.datetime.fromtimestamp(modified).date().isoformat()


@dataclass
class Analysis:
    company_id: Optional[int]
    company_name: str
    confidence: float
    category: str
    explanation: str
    document_date: str
    references: str
    extracted_text: str
    ai_used: bool = False


class FileManagerCore:
    def __init__(self, root: Path, seed_companies: bool = True):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.meta = self.root / ".filemanager"
        self.meta.mkdir(exist_ok=True)
        (self.meta / "staging").mkdir(exist_ok=True)
        (self.meta / "recycle").mkdir(exist_ok=True)
        self.conn = sqlite3.connect(str(self.meta / "library.sqlite"), check_same_thread=False, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self._schema()
        if seed_companies and not self.companies():
            for name, aliases in DEFAULT_COMPANIES:
                self.add_company(name, aliases)

    def _schema(self):
        with self.lock, self.conn:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS companies (
                id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, aliases TEXT DEFAULT '',
                folder TEXT NOT NULL UNIQUE, created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY, company_id INTEGER REFERENCES companies(id),
                title TEXT NOT NULL, relative_path TEXT NOT NULL UNIQUE,
                original_path TEXT, fingerprint TEXT UNIQUE NOT NULL, category TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'review', confidence REAL NOT NULL DEFAULT 0,
                reason TEXT DEFAULT '', document_date TEXT, ref TEXT DEFAULT '', tags TEXT DEFAULT '',
                content TEXT DEFAULT '', size INTEGER, added_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            self.conn.execute("CREATE INDEX IF NOT EXISTS ix_docs_company ON documents(company_id)")
            self.conn.execute("CREATE INDEX IF NOT EXISTS ix_docs_state ON documents(state)")
            self.conn.execute("CREATE INDEX IF NOT EXISTS ix_docs_date ON documents(document_date)")
            try:
                self.conn.execute("CREATE VIRTUAL TABLE IF NOT EXISTS document_search USING fts5(title, content, refs, tags, tokenize='unicode61')")
                self.has_fts = True
            except sqlite3.OperationalError:
                self.has_fts = False

    def close(self):
        with self.lock:
            self.conn.close()

    def companies(self) -> list[dict]:
        with self.lock:
            rows = self.conn.execute("""SELECT c.*,
                (SELECT COUNT(*) FROM documents d WHERE d.company_id=c.id AND d.state='filed') AS file_count
                FROM companies c ORDER BY name COLLATE NOCASE""").fetchall()
            return [dict(row) for row in rows]

    def add_company(self, name: str, aliases: str = "") -> int:
        name = name.strip()
        if not name or len(name) > 120:
            raise ValueError("Enter a valid company name (maximum 120 characters).")
        with self.lock, self.conn:
            if self.conn.execute("SELECT 1 FROM companies WHERE LOWER(name)=LOWER(?)", (name,)).fetchone():
                raise ValueError("This company already exists.")
            base = safe_folder(name)
            folder = base
            existing = {r["folder"].casefold() for r in self.conn.execute("SELECT folder FROM companies")}
            n = 2
            while folder.casefold() in existing or (self.root / folder).exists():
                folder = f"{base[:76]} ({n})"
                n += 1
            self.root.joinpath(folder).mkdir(exist_ok=False)
            cur = self.conn.execute("INSERT INTO companies (name,aliases,folder) VALUES (?,?,?)", (name, aliases.strip(), folder))
            return int(cur.lastrowid)

    def update_company(self, company_id: int, name: str, aliases: str):
        name = name.strip()
        if not name:
            raise ValueError("Company name is required.")
        with self.lock, self.conn:
            self.conn.execute("UPDATE companies SET name=?,aliases=? WHERE id=?", (name, aliases.strip(), company_id))
            # Physical folder remains stable to avoid broken paths.

    def remove_company(self, company_id: int):
        with self.lock, self.conn:
            count = self.conn.execute("SELECT COUNT(*) FROM documents WHERE company_id=?", (company_id,)).fetchone()[0]
            if count:
                raise ValueError("This company contains indexed files. Reassign them before removing it.")
            row = self.conn.execute("SELECT folder FROM companies WHERE id=?", (company_id,)).fetchone()
            if not row:
                return
            folder = self.root / row["folder"]
            if folder.exists() and any(folder.iterdir()):
                raise ValueError("Company folder is not empty. Nothing was deleted.")
            self.conn.execute("DELETE FROM companies WHERE id=?", (company_id,))
            if folder.exists():
                folder.rmdir()

    def get_company(self, company_id: int) -> dict:
        row = self.conn.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
        if row is None:
            raise ValueError("Choose a valid company.")
        return dict(row)

    def classify(self, path: Path, extracted: Optional[str] = None) -> Analysis:
        content = extracted if extracted is not None else extract_text(path)
        filename = normalized(path.stem).replace("_", " ").replace("-", " ")
        maintext = normalized(content[:30000])
        scores = []
        for c in self.companies():
            aliases = [c["name"], *c["aliases"].split(",")]
            best = 0.0
            match_reason = ""
            for alias in aliases:
                alias = normalized(alias.strip())
                if len(alias) < 4:
                    continue
                expression = r"(?<![a-z0-9])" + re.escape(alias) + r"(?![a-z0-9])"
                if re.search(expression, filename):
                    score = 0.97 if len(alias) >= 8 else 0.89
                    reason = f"Company alias '{alias}' in filename"
                else:
                    count = len(re.findall(expression, maintext))
                    if count:
                        score = min(0.86, 0.61 + (0.08 if len(alias) >= 8 else 0) + min(count, 3) * 0.055)
                        reason = f"Company alias '{alias}' in document text"
                    else:
                        score = 0.0
                        reason = ""
                if score > best:
                    best, match_reason = score, reason
            if best:
                scores.append((best, c, match_reason))
        scores.sort(key=lambda x: x[0], reverse=True)
        company, company_name, confidence = None, "Unassigned", 0.0
        reason = "No confident company match; please review"
        if scores:
            confidence, chosen, reason = scores[0]
            company, company_name = chosen["id"], chosen["name"]
            if len(scores) > 1 and scores[1][0] >= confidence - 0.13:
                confidence = min(confidence, 0.55)
                reason = f"Multiple companies detected: {chosen['name']} / {scores[1][1]['name']}"
        category, category_score = "Other", 0
        typed = filename + "\n" + maintext[:12000]
        for cat, patterns in CATEGORY_PATTERNS.items():
            score = sum((6 if re.search(pattern, filename, re.I) else 0) + (1 if re.search(pattern, maintext[:12000], re.I | re.S) else 0) for pattern in patterns)
            if score > category_score:
                category, category_score = cat, score
        if path.suffix.casefold() == ".eml" and category_score < 5:
            category = "Correspondence"
        date = infer_date(path.stem + "\n" + content[:3000], path.stat().st_mtime)
        refs = reference_candidates(path.stem + "\n" + content[:10000])
        return Analysis(company, company_name, confidence, category, reason, date, refs, content)

    def _abs(self, relative: str) -> Path:
        path = (self.root / relative).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("Invalid path outside managed library")
        return path

    def _unique_dest(self, directory: Path, filename: str) -> Path:
        directory.mkdir(parents=True, exist_ok=True)
        base = safe_folder(Path(filename).stem)
        ext = Path(filename).suffix.casefold()
        dest = directory / (base + ext)
        i = 2
        while dest.exists():
            dest = directory / f"{base[:66]} ({i}){ext}"
            i += 1
        return dest

    def _stage(self, source: Path) -> Path:
        dest = self.meta / "staging" / f"{uuid.uuid4().hex}{source.suffix.lower()}"
        shutil.copy2(str(source), str(dest))
        return dest

    def _move_into_company(self, staged: Path, company_id: int, category: str, document_date: str, original_name: str) -> Path:
        c = self.get_company(company_id)
        year = (document_date or "")[:4]
        if not re.fullmatch(r"20\d{2}", year):
            year = "Undated"
        dest = self._unique_dest(self.root / c["folder"] / safe_folder(category) / year, original_name)
        # Stage and destination are inside selected library, so rename is atomic on one filesystem.
        os.replace(str(staged), str(dest))
        return dest

    def _index(self, doc_id: int, title: str, content: str, refs: str, tags: str):
        if self.has_fts:
            self.conn.execute("DELETE FROM document_search WHERE rowid=?", (doc_id,))
            self.conn.execute("INSERT INTO document_search (rowid,title,content,refs,tags) VALUES (?,?,?,?,?)", (doc_id, title, content, refs, tags))

    def import_file(self, source: Path, ai=None, move_original: bool = False, auto_file: bool = True) -> dict:
        source = Path(source).expanduser().resolve()
        if not source.is_file():
            return {"status": "skipped", "name": source.name, "message": "Not a file"}
        if source.suffix.lower() not in SUPPORTED:
            return {"status": "skipped", "name": source.name, "message": "Unsupported file type"}
        if source.is_relative_to(self.root):
            return {"status": "skipped", "name": source.name, "message": "File is already in the library"}
        fingerprint = hash_file(source)
        with self.lock:
            old = self.conn.execute("SELECT id,relative_path FROM documents WHERE fingerprint=?", (fingerprint,)).fetchone()
        if old:
            return {"status": "duplicate", "name": source.name, "id": old["id"], "message": old["relative_path"]}
        staged = self._stage(source)
        try:
            analysis = self.classify(source)
            if ai and callable(ai):
                try:
                    proposal = ai(source, analysis, self.companies())
                    if proposal:
                        names = {c["id"]: c["name"] for c in self.companies()}
                        identifier = proposal.get("company_id")
                        if "company_id" in proposal and identifier is None:
                            analysis.company_id = None
                            analysis.company_name = "Unassigned"
                            analysis.confidence = 0.0
                            analysis.explanation = "AI: company not identified confidently"
                        if identifier in names:
                            analysis.company_id = identifier
                            analysis.company_name = names[identifier]
                            analysis.confidence = max(0.0, min(0.99, float(proposal.get("confidence", 0))))
                            analysis.explanation = "AI: " + str(proposal.get("reason", "Suggested classification"))[:250]
                            analysis.ai_used = True
                        cat = proposal.get("category")
                        if cat in CATEGORIES:
                            analysis.category = cat
                except Exception as exc:
                    analysis.explanation += " | AI unavailable: " + str(exc)[:120]
            state = "filed" if auto_file and analysis.company_id and analysis.confidence >= 0.85 else "review"
            if state == "filed":
                dest = self._move_into_company(staged, analysis.company_id, analysis.category, analysis.document_date, source.name)
            else:
                dest = staged
            relative = str(dest.relative_to(self.root))
            with self.lock, self.conn:
                cur = self.conn.execute("""INSERT INTO documents
                    (company_id,title,relative_path,original_path,fingerprint,category,state,confidence,reason,document_date,ref,content,size)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                    analysis.company_id, source.name, relative, str(source), fingerprint, analysis.category,
                    state, analysis.confidence, analysis.explanation, analysis.document_date,
                    analysis.references, analysis.extracted_text, source.stat().st_size,
                ))
                doc_id = cur.lastrowid
                self._index(doc_id, source.name, analysis.extracted_text, analysis.references, "")
            if state == "filed" and move_original:
                try:
                    if hash_file(dest) == fingerprint:
                        source.unlink()
                except OSError:
                    pass
            return {"status": state, "name": source.name, "id": doc_id, "company": analysis.company_name, "category": analysis.category, "confidence": analysis.confidence}
        except Exception:
            # Never delete a staged copy after a partial operation; preserve for recovery.
            raise

    def approve(self, doc_id: int, company_id: int, category: str = "Other", move_original: bool = False):
        if category not in CATEGORIES:
            raise ValueError("Invalid document category")
        with self.lock:
            row = self.conn.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
            if not row:
                raise ValueError("File was not found")
            source = self._abs(row["relative_path"])
            if not source.exists():
                raise FileNotFoundError(str(source))
            destination = self._move_into_company(source, company_id, category, row["document_date"], row["title"])
            with self.conn:
                self.conn.execute("""UPDATE documents SET company_id=?,relative_path=?,category=?,state='filed',
                    confidence=1,reason='Confirmed by user',updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                    (company_id, str(destination.relative_to(self.root)), category, doc_id))
            if move_original and row["state"] == "review" and row["original_path"]:
                original = Path(row["original_path"])
                if original.exists() and hash_file(original) == row["fingerprint"]:
                    original.unlink()

    def change_tags(self, doc_id: int, tags: str):
        with self.lock, self.conn:
            self.conn.execute("UPDATE documents SET tags=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (tags[:400], doc_id))
            row = self.conn.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
            if row:
                self._index(doc_id, row["title"], row["content"], row["ref"], row["tags"])

    def remove_from_library(self, doc_id: int):
        """Reversible removal: move document into hidden recycle; retain original when already copied."""
        with self.lock:
            row = self.conn.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
            if not row:
                return
            source = self._abs(row["relative_path"])
            if source.exists():
                target = self.meta / "recycle" / (uuid.uuid4().hex + "_" + safe_folder(row["title"]))
                os.replace(str(source), str(target))
            with self.conn:
                if self.has_fts:
                    self.conn.execute("DELETE FROM document_search WHERE rowid=?", (doc_id,))
                self.conn.execute("DELETE FROM documents WHERE id=?", (doc_id,))

    def document(self, doc_id: int) -> dict:
        with self.lock:
            row = self.conn.execute("""SELECT d.*,c.name company_name,c.folder company_folder FROM documents d
                LEFT JOIN companies c ON c.id=d.company_id WHERE d.id=?""", (doc_id,)).fetchone()
            if not row:
                raise ValueError("Document not found")
            d = dict(row)
        d["absolute_path"] = str(self._abs(d["relative_path"]))
        return d

    def summary(self) -> dict:
        with self.lock:
            d = self.conn.execute("""SELECT COUNT(*) total,
                SUM(CASE WHEN state='filed' THEN 1 ELSE 0 END) filed,
                SUM(CASE WHEN state='review' THEN 1 ELSE 0 END) review
                FROM documents""").fetchone()
            return {"total": d["total"] or 0, "filed": d["filed"] or 0, "review": d["review"] or 0, "companies": len(self.companies())}

    def search(self, query: str = "", company_id: Optional[int] = None, state: str = "all", limit: int = 250) -> list[dict]:
        """Hybrid search combines FTS5 text matches with filename, reference and fuzzy matches."""
        query = (query or "").strip()
        explicit_year = re.search(r"\byear:(20\d{2})\b", query, re.I)
        normal_query = normalized(query)
        mentioned_year = re.search(r"\b20\d{2}\b", normal_query)
        month_words = tokens(normal_query)
        selected_month = next((MONTHS[t] for t in month_words if t in MONTHS), None)
        explicit_type = re.search(r"\btype:([\w_-]+)\b", query, re.I)
        query = re.sub(r"\b(?:year|type):[^\s]+", "", query, flags=re.I).strip()
        filtered_tokens = [t for t in tokens(query) if t not in STOPWORDS and t not in MONTHS]
        if selected_month:
            filtered_tokens = [t for t in filtered_tokens if not re.fullmatch(r"20\d{2}", t)]
        fts_ids = set()
        with self.lock:
            if query and self.has_fts and filtered_tokens:
                term = " OR ".join('"' + t.replace('"','') + '"*' for t in filtered_tokens[:12])
                try:
                    fts_ids = {r[0] for r in self.conn.execute("SELECT rowid FROM document_search WHERE document_search MATCH ? LIMIT 800", (term,))}
                except sqlite3.OperationalError:
                    pass
            where = ["1=1"]
            params = []
            if company_id is not None:
                where.append("d.company_id=?")
                params.append(company_id)
            if state != "all":
                where.append("d.state=?")
                params.append(state)
            if selected_month and (explicit_year or mentioned_year):
                chosen_year = explicit_year.group(1) if explicit_year else mentioned_year.group(0)
                where.append("d.document_date LIKE ?")
                params.append(f"{chosen_year}-{selected_month:02d}%")
            elif selected_month:
                where.append("substr(d.document_date,6,2)=?")
                params.append(f"{selected_month:02d}")
            elif explicit_year:
                where.append("d.document_date LIKE ?")
                params.append(explicit_year.group(1) + "%")
            if explicit_type:
                where.append("LOWER(d.category) LIKE ?")
                params.append("%" + explicit_type.group(1).replace("_", " ").lower() + "%")
            rows = self.conn.execute("""SELECT d.id,d.title,d.category,d.state,d.confidence,d.reason,
                d.document_date,d.ref,d.tags,d.relative_path,d.size,d.added_at,d.company_id,
                COALESCE(c.name,'Unassigned') company_name
                FROM documents d LEFT JOIN companies c ON c.id=d.company_id
                WHERE """ + " AND ".join(where) + " ORDER BY d.added_at DESC LIMIT 12000", params).fetchall()
            if filtered_tokens:
                # Index contents are queried using FTS; avoid pulling all document text into memory.
                pass
        scored = []
        for r in rows:
            item = dict(r)
            if not filtered_tokens:
                item["score"] = 0
                scored.append(item)
                continue
            metadata = normalized(" ".join(str(item.get(k) or "") for k in ("title", "company_name", "category", "ref", "tags", "document_date")))
            title = normalized(item["title"])
            from difflib import SequenceMatcher
            score = sum(5 if t in title else 3 if t in metadata else 0 for t in filtered_tokens)
            if item["id"] in fts_ids:
                score += 7
            if query and normalized(query) in metadata:
                score += 12
            if score == 0 and len(query) > 3:
                ratio = SequenceMatcher(None, normalized(query), title).ratio()
                score = 2 if ratio > 0.65 else 0
            if score:
                item["score"] = score
                scored.append(item)
        if filtered_tokens:
            scored.sort(key=lambda x: (x["score"], x["added_at"]), reverse=True)
        return scored[:limit]

    def export_index_csv(self, path: Path, rows: Optional[list[dict]] = None):
        rows = rows if rows is not None else self.search(limit=100000)
        cols = ["id", "title", "company_name", "category", "state", "document_date", "ref", "tags", "relative_path", "size", "added_at"]
        with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)

    def backup_index(self, destination: Path):
        # SQLite online backup is consistent even while the index is open.
        with self.lock:
            target = sqlite3.connect(str(destination))
            try:
                self.conn.backup(target)
            finally:
                target.close()

    def missing_files(self) -> list[dict]:
        return [d for d in self.search(limit=12000) if not self._abs(d["relative_path"]).is_file()]

    def import_many(self, paths, callback=None, ai=None, move_original=False, auto_file=True):
        paths = list(paths)
        sources = []
        for path in paths:
            p = Path(path)
            if p.is_dir() and not p.is_relative_to(self.root):
                for folder, subdirs, filenames in os.walk(p):
                    subdirs[:] = [s for s in subdirs if not s.startswith(".")]
                    for filename in filenames:
                        if Path(filename).suffix.casefold() in SUPPORTED:
                            sources.append(Path(folder) / filename)
            elif p.is_file():
                sources.append(p)
        results = []
        for i, path in enumerate(sources):
            try:
                results.append(self.import_file(path, ai=ai, move_original=move_original, auto_file=auto_file))
            except Exception as exc:
                results.append({"status": "error", "name": path.name, "message": str(exc)})
            if callback:
                callback(i + 1, len(sources), results[-1])
        return results
