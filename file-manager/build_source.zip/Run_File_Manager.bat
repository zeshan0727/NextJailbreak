@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title File Manager v1.1 - Light Edition
if exist "File Manager.exe" (
  start "" "%~dp0File Manager.exe"
  exit /b 0
)
if exist "dist\File Manager.exe" (
  start "" "%~dp0dist\File Manager.exe"
  exit /b 0
)
set "LOG=%TEMP%\File_Manager_Startup.log"
echo === Starting File Manager v1.1 ===
echo Startup %DATE% %TIME% > "%LOG%"
echo Working directory: %CD% >> "%LOG%"
if exist ".venv\Scripts\python.exe" goto launch
where py >nul 2>&1
if not errorlevel 1 (
    set "PYCMD=py -3"
) else (
    where python >nul 2>&1
    if not errorlevel 1 (
        set "PYCMD=python"
    ) else (
        goto no_python
    )
)
echo Checking Python...
%PYCMD% -c "import sys; assert sys.version_info >= (3,11), 'Python 3.11+ required'" >> "%LOG%" 2>&1
if errorlevel 1 goto no_python
echo Creating application environment...
%PYCMD% -m venv .venv >> "%LOG%" 2>&1
if errorlevel 1 goto fail
echo Installing only the required startup libraries (first time only)...
.venv\Scripts\python.exe -m pip install --disable-pip-version-check -r requirements.txt >> "%LOG%" 2>&1
if errorlevel 1 goto fail
:launch
if not exist ".venv\Scripts\python.exe" goto fail
echo Opening desktop window...
.venv\Scripts\python.exe file_manager.py >> "%LOG%" 2>&1
if errorlevel 1 goto fail
exit /b 0
:no_python
echo.
echo Python is missing or unsupported. Nothing was installed.
echo EASIEST: Use the portable File Manager.exe build - no Python required.
echo ALTERNATIVE: Install Python 3.12 from https://www.python.org/downloads/windows/
echo             and tick "Add python.exe to PATH".
echo.
goto fail
:fail
echo.
echo File Manager did not start. Exact diagnostic is saved to:
echo %LOG%
echo.
if exist "%LOG%" type "%LOG%"
echo.
echo Send the above error or the log when asking for support.
pause
exit /b 1
