@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
where py >nul 2>&1
if not errorlevel 1 (
 set "PYCMD=py -3"
) else (
 where python >nul 2>&1
 if errorlevel 1 goto fail
 set "PYCMD=python"
)
%PYCMD% -m venv .venv
if errorlevel 1 goto fail
:install
.venv\Scripts\python.exe -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto fail
exit /b 0
:fail
echo Python setup failed. Install Python 3.12 or use a portable EXE.
pause
exit /b 1
