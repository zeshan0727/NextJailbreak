# File Manager for Windows — v1.1 (Light Edition)

**A private, company-wise, searchable document library** for accounting and office paperwork. Add companies, drag documents into one Smart Intake area, and search across all companies by a short reference, phrase, document type, tag, or date.

## What the app does

- One central **drag-and-drop** intake zone (both Windows packaged and source installs when tkinterdnd2 is available), plus an **Import files** picker and multi-file/folder drop.
- Custom company sections with **aliases and abbreviations**. Seven company sections are preloaded as an editable starter list.
- Company detection from the **filename and extracted document text**, with confidence scoring and explicit ambiguity checks.
- Filing into `Library / Company / Category / Year / Original Filename`.
- Categorizes invoices, bills, payment vouchers, receipts, bank statements, purchase orders, contracts, payroll, HR, tax, audit and other documents.
- An **Needs Review** queue for unclear company matches. Files remain safe in the library's hidden staging folder until approved.
- Detects exact duplicates using **SHA-256** and never overwrites an existing document with the same name.
- **Global smart search**: extracted text, company, invoice/voucher references, filename, date, tags; indexed with SQLite full-text search (FTS5) and fuzzy metadata fallback. Supports search terms such as `PV-BJ-260014`, `Barjous October 2026`, `rent`, `year:2026` and `type:invoice`.
- **AI Find** (optional): AI expands the search into useful keywords, interprets company and time constraints, then searches the **local** index. No document text is sent for AI Find.
- Document detail panel, extracted text preview, one-click opening, reassign, searchable custom tags, and CSV export.
- Local SQLite index and a consistent **Backup index** action. All actual documents live in the library folder.
- First-run safety: **keeps the original source document** until you explicitly enable moving originals in Settings.

## Recommended Windows launch (portable EXE or source)

**Best experience:** Double-click **`File Manager.exe`** if present in the release package. It opens the native light interface without Python, a black console, or pip. The EXE must be compiled on Windows through GitHub Actions or the included build script.

**Source fallback** when the EXE is not included:

1. Extract the entire ZIP to a normal writable folder, e.g. `Downloads\File_Manager_Windows`.
2. Install **Python 3.12** from [python.org](https://www.python.org/downloads/windows/) if it's not already installed. Enable *Add Python to PATH* during installation.
3. Double-click **`Run_File_Manager.bat`**. The first launch creates a private `.venv`, downloads the two minimum application dependencies, and opens the app. The diagnostic log is in `%TEMP%\File_Manager_Startup.log` if something fails. Later launches reuse those dependencies.
4. Drag documents into Smart Intake or use **Import files**.
5. Use the company menu to add/edit names and aliases. Any uncertain document appears in **Needs review** for assignment.

> Windows Defender may show a normal warning for an unsigned custom executable you build. No administrator privileges are required for the app itself or for storing documents under your own account.

## How to build a portable `File Manager.exe`

**Option A — directly on Windows:** With Python installed, double-click `Build_Windows_EXE.bat`. The output will appear at `dist\File Manager.exe`. No Python installation is required on the destination PC for the compiled executable.

**Option B — GitHub Actions, without a local compiler:** Upload this project under `file-manager/` in a GitHub repository, and save the workflow from `.github/workflows/build-windows.yml` as `.github/workflows/file-manager-windows.yml`; use the branch `file-manager-windows-v1-1`, or adapt its push trigger. Run **Actions → File Manager Windows EXE**. Open the successful run and download the **File-Manager-Windows-Portable** artifact. Extract it to find `File Manager.exe`.

The GitHub workflow runs unit tests before packaging. Do **not** upload your actual business document library, SQLite database, or API key to GitHub.

> The included source supports building a Windows EXE, and tests pass locally. If the ZIP has no `.exe`, the EXE must first be built on Windows using `Build_Windows_EXE.bat` or GitHub Actions. A Linux-based UI smoke test is not the same as a real Windows executable test.

## Supported files and OCR

| Document | Automatic text extraction |
| --- | --- |
| Text-based PDFs | Yes (`pypdf`) |
| Scanned PDFs | Optional local OCR (first 5 pages) when Tesseract OCR is installed |
| Word `.docx` | Yes |
| Excel `.xlsx` / `.xlsm` | Yes: worksheet values and shared strings |
| PowerPoint `.pptx` | Yes: slide text |
| `.txt`, `.csv`, `.eml`, `.html`, `.json`, `.rtf` | Yes |
| `.png`, `.jpg`, `.tiff`, `.bmp` | Optional local OCR when Tesseract OCR is installed |
| Legacy `.doc`, `.xls`, Outlook `.msg` | Filename and metadata only in v1 |

To enable optional OCR, first run `.venv\Scripts\python.exe -m pip install -r requirements-ocr.txt`, then install Tesseract OCR for Windows in `C:\Program Files\Tesseract-OCR`. The app detects that standard location automatically; no cloud OCR is required. For scanned documents whose OCR is not available, the app can still classify by filename and routes uncertain files into review.

## Optional OpenAI classification (not required)

In **Settings** turn on *Use OpenAI to analyze extracted text*, then enter your own API key and model (default: `gpt-4o-mini`). The API key is encrypted using **Windows DPAPI** for your signed-in Windows account. **There is no bundled API key** and OpenAI API usage may incur charges. The app only sends the filename, company names/aliases, and a maximum of **10,000 characters of extracted document text** when classifying; no complete PDFs, files, or images are uploaded. AI Find sends your search phrase and company names/aliases, without document contents. AI is fully optional and off by default.

The app does not provide embeddings-based local semantic search; its offline search is full-text, reference-aware, date-aware, and fuzzy. AI Find adds natural-language query interpretation when enabled.

## Library storage and safety

- Default library: `Documents\File Manager Library`. Change the folder under **Settings**. Use a normal local folder on a reliable drive.
- Index/database: `Library\.filemanager\library.sqlite`.
- Files needing review: `Library\.filemanager\staging`.
- Recycled document copies: `Library\.filemanager\recycle` (internal safe removal mechanism).
- Originals are **copied**, not removed, by default. If *Move originals after verified filing* is enabled, source originals are removed only after the filed copy's hash is verified.
- Changing company name leaves the physical folder name intact, so document links stay valid.
- Back up the **entire library folder** regularly. `Backup index` makes only a consistent snapshot of the search database — it is not a backup of the documents.

## Windows keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| Ctrl + K or Ctrl + F | Focus global search |
| Ctrl + O | Import documents |
| Ctrl + N | Add a company |
| F5 | Refresh list |
| Double-click document | Open in default Windows application |
| Right-click document | Assign, open, reveal, edit tags |

## Run automated tests

```powershell
python -m unittest discover -s tests -v
```

## Architecture

Python 3.12 / Tkinter desktop UI + tkinterdnd2 for real native drag-and-drop, SQLite + FTS5 local index, pypdf / XML-based Office extraction, optional PyMuPDF + Tesseract OCR, optional direct OpenAI API integration over HTTPS. Standard-library threading keeps the interface responsive during batch imports. Windows portable executable produced with PyInstaller.

## Current limitations

This is a usable **v1.1**, not a validated enterprise document-management system. It does not provide user permissions, shared/network multi-user databases, background filesystem monitoring, document version history, automatic encrypted backups, or guaranteed recognition of badly scanned/handwritten files. File dates can be inferred incorrectly and should be checked on important records. Extracted text is truncated for performance; search cannot retrieve words beyond the extraction cap. Verify classifications before relying on the folder as an official records repository.
