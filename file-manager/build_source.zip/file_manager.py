"""Windows desktop entrypoint: File Manager."""
from filemanager.gui import main

if __name__ == "__main__":
    main()
