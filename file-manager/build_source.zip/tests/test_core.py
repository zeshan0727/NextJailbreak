import csv
import tempfile
import unittest
import zipfile
from pathlib import Path

from filemanager.core import FileManagerCore, safe_folder, extract_text


class FileManagerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.lib = FileManagerCore(self.base / "File Library", seed_companies=False)
        self.addCleanup(self.lib.close)
        self.barjous_id = self.lib.add_company("Barjous Architects", "barjous,barjous engineering")
        self.graphitees_id = self.lib.add_company("The Graphitees WLL", "graphitees,the graphitees")

    def source(self, filename, text):
        p = self.base / filename
        p.write_text(text, encoding="utf-8")
        return p

    def test_file_invoice_auto_classifies_and_keeps_original(self):
        src = self.source("Barjous INV-0140.txt", "TAX INVOICE Barjous Architects invoice number: INV-0140 dated 2026-09-10")
        result = self.lib.import_file(src)
        self.assertEqual(result["status"], "filed")
        self.assertEqual(result["company"], "Barjous Architects")
        self.assertEqual(result["category"], "Invoices & Bills")
        self.assertTrue(src.exists())
        doc = self.lib.document(result["id"])
        self.assertTrue(Path(doc["absolute_path"]).exists())
        self.assertEqual(doc["document_date"], "2026-09-10")
        self.assertIn("2026", doc["relative_path"])

    def test_month_year_and_type_filters(self):
        a = self.source("Barjous March invoice.txt", "Barjous invoice\nDate 2026-03-16")
        b = self.source("Barjous April invoice.txt", "Barjous invoice\nDate 2026-04-16")
        self.lib.import_file(a)
        self.lib.import_file(b)
        self.assertEqual([r["title"] for r in self.lib.search("Barjous March 2026")], [a.name])
        self.assertEqual(len(self.lib.search("year:2026 type:invoices")), 2)

    def test_duplicate_hash_suppressed(self):
        a = self.source("Graphitees payment voucher.txt", "The Graphitees WLL payment voucher\nPV-GR-2026001")
        first = self.lib.import_file(a)
        second = self.lib.import_file(a)
        self.assertEqual(first["status"], "filed")
        self.assertEqual(second["status"], "duplicate")
        self.assertEqual(self.lib.summary()["total"], 1)

    def test_unknown_company_requires_review(self):
        src = self.source("Unknown memo.txt", "Internal agreement regarding maintenance")
        item = self.lib.import_file(src)
        self.assertEqual(item["status"], "review")
        self.assertEqual(self.lib.summary()["review"], 1)
        self.lib.approve(item["id"], self.graphitees_id, "Contracts")
        self.assertEqual(self.lib.document(item["id"])["state"], "filed")
        self.assertIn("Contracts", self.lib.document(item["id"])["relative_path"])
        self.assertTrue(src.exists())

    def test_two_companies_detected_from_text_blocks_auto_filing(self):
        src = self.source("unnamed.txt", "Barjous Architects and The Graphitees WLL entered into an agreement. Barjous Architects confirms. The Graphitees WLL confirms.")
        result = self.lib.import_file(src)
        self.assertEqual(result["status"], "review")
        self.assertIn("Multiple companies", self.lib.document(result["id"])["reason"])

    def test_full_text_short_reference_and_tags(self):
        src = self.source("Barjous details.txt", "Reference ABC789642 unexpected nichewordfall payment")
        item = self.lib.import_file(src)
        self.assertEqual(item["status"], "filed")
        self.assertEqual(len(self.lib.search("nichewordfall")), 1)
        self.assertEqual(len(self.lib.search("ABC789642")), 1)
        self.assertEqual(len(self.lib.search("find Barjous reference")), 1)
        self.lib.change_tags(item["id"], "annual, urgent, QNB")
        self.assertEqual(len(self.lib.search("QNB")), 1)
        self.assertEqual(len(self.lib.search("year:2026")), 1)

    def test_file_conflicts_rename_without_overwrite(self):
        p1 = self.source("Barjous invoice.txt", "Barjous invoice: first version")
        first = self.lib.import_file(p1)
        p1.write_text("Barjous invoice: updated version")
        second = self.lib.import_file(p1)
        self.assertNotEqual(first["id"], second["id"])
        self.assertNotEqual(self.lib.document(first["id"])["relative_path"], self.lib.document(second["id"])["relative_path"])
        self.assertTrue(Path(self.lib.document(first["id"])["absolute_path"]).exists())

    def test_move_original_only_when_enabled(self):
        src = self.source("Barjous invoice move.txt", "Barjous invoice paid")
        result = self.lib.import_file(src, move_original=True)
        self.assertEqual(result["status"], "filed")
        self.assertFalse(src.exists())
        self.assertTrue(Path(self.lib.document(result["id"])["absolute_path"]).exists())

    def test_remove_recycles_not_erases(self):
        src = self.source("Barjous invoice.txt", "Barjous invoice 1000")
        result = self.lib.import_file(src)
        self.lib.remove_from_library(result["id"])
        self.assertEqual(self.lib.summary()["total"], 0)
        self.assertEqual(len(list((self.lib.meta / "recycle").iterdir())), 1)
        self.assertTrue(src.exists())

    def test_index_export_and_backup(self):
        self.lib.import_file(self.source("Barjous invoice.txt", "Barjous invoice 1000"))
        dest = self.base / "index.csv"
        self.lib.export_index_csv(dest)
        with dest.open(encoding="utf-8-sig", newline="") as f:
            self.assertEqual(len(list(csv.DictReader(f))), 1)
        backup = self.base / "backup.sqlite"
        self.lib.backup_index(backup)
        self.assertGreater(backup.stat().st_size, 0)

    def test_docx_text_extract(self):
        sample = self.base / "Barjous doc.docx"
        with zipfile.ZipFile(sample, "w") as z:
            z.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Contract for Barjous Engineering</w:t></w:r></w:p></w:body></w:document>')
        self.assertIn("Barjous Engineering", extract_text(sample))

    def test_safe_windows_foldernames(self):
        self.assertEqual(safe_folder("CON"), "CON Folder")
        self.assertEqual(safe_folder("  My:Company*?  "), "My Company")


if __name__ == "__main__":
    unittest.main()
