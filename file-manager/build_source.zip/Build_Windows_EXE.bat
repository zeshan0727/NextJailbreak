@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Building File Manager Portable EXE
call Run_Install_Requirements.bat
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install --disable-pip-version-check "pyinstaller==6.16.0"
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m unittest discover -s tests -v
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m PyInstaller --clean --noconfirm --onefile --windowed --name "File Manager" --icon "assets\file_manager.ico" --collect-all tkinterdnd2 "file_manager.py"
if errorlevel 1 goto fail
if not exist "dist\File Manager.exe" goto fail
echo.
echo EXE READY: %CD%\dist\File Manager.exe
echo Copy this file to any Windows 10/11 PC. Python is not required.
pause
exit /b 0
:fail
echo.
echo Windows build failed. Review the error shown above.
pause
exit /b 1
